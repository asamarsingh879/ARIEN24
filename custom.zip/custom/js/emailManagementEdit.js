var siteUrl = _spPageContextInfo.webServerRelativeUrl;
//var siteUrl = _spPageContextInfo.siteAbsoluteUrl;
var listName = "Email Management";
var libraryName = "EmailManagementAttachments";
var companyCodeDetailsArray = [];
var ddlRegionVal = "";
var ddlFromTeamVal = "";
var ddlAssignedToVal = "";
var ddlCompanyCodeVal = "";
var ddlAssignedToPersonVal = "";
var fileAlreadyExists = false;
var currentUserGroupName = "";
var currentUserName = "";
var queryStrVal = [];
var needToReassign = false;
var needToDelegate = false;
var reAllocateRequest = false;
var currentDateTime = "";
var statusRejectVal = "";
var requestAssignedToGroup = "";
var isAdmin;
var isSupervisor;
var isAssignedToGroupUser;

$(document).ready(function () {
  getRegionDetails();
  getFromTeamDetails();
  getCompanyCodeDetails();
  getCurrentUserGroupName();
  getCurrentUserName();
  disableColumns();
  getQueryStrVal();

  isAdmin = isMemberOfGroup("Admins");
  isSupervisor = isMemberOfGroup("Managers-or-Supervisors");
  // alert("isSupervisor: " + isSupervisor);

  // getDateTime();

  $("#divReallocateRequestToInput").change(function () {
    ddlCountryVal = "";
    var reAllocatedPersonVal = $(
      "#divReallocateRequestToInput option:selected"
    ).text();

    var createdBy = $("#createByInput").val();
    // getCountryValues(regionVal);
    if (reAllocatedPersonVal == "Select") {
    } else {
      if (reAllocatedPersonVal === createdBy) {
        alert(
          "You should not reallocate to the same person - " +
            reAllocatedPersonVal
        );
        document.getElementById(
          "divReallocateRequestToInputNew"
        ).selectedIndex = "0";
      } else {
      }
    }
  });

  $("#companyCodeInput").change(function () {
    var companyCodeVal = $("#companyCodeInput option:selected").text();
    if (companyCodeVal == "Select") {
      $("#subTeamInput").val("");
    } else {
      console.log(
        "companyCodeDetailsArray(): " + JSON.stringify(companyCodeDetailsArray)
      );
      if (companyCodeDetailsArray.length > 0) {
        for (var i = 0; i < companyCodeDetailsArray.length; i++) {
          if (companyCodeDetailsArray[i].companyCode === companyCodeVal) {
            $("#subTeamInput").val(companyCodeDetailsArray[i].subTeam);
          }
        }
      }
    }
  });

  $("#companyCodeInput").change(function () {
    var companyCodeVal = $("#companyCodeInput option:selected").text();
    if (companyCodeVal == "Select") {
      $("#subTeamInput").val("");
    } else {
      console.log(
        "companyCodeDetailsArray(): " + JSON.stringify(companyCodeDetailsArray)
      );
      if (companyCodeDetailsArray.length > 0) {
        for (var i = 0; i < companyCodeDetailsArray.length; i++) {
          if (companyCodeDetailsArray[i].companyCode === companyCodeVal) {
            $("#subTeamInput").val(companyCodeDetailsArray[i].subTeam);
          }
        }
      }
    }
  });

  $("#btnSubmit").click(function () {
    var regionInputVal = $("#regionInput option:selected").text();
    if (regionInputVal !== "Select") {
    } else {
      regionInputVal = "";
    }

    var fromTeamInputVal = $("#fromTeamInput option:selected").text();
    if (fromTeamInputVal !== "Select") {
    } else {
      fromTeamInputVal = "";
    }

    var companyCodeInputVal = $("#companyCodeInput option:selected").text();
    if (companyCodeInputVal !== "Select") {
    } else {
      companyCodeInputVal = "";
    }
    var subjectInputVal = $("#subjectInput").val();
    var assignedToInputVal = $("#assignedToInput option:selected").text();
    if (assignedToInputVal !== "Select") {
    } else {
      assignedToInputVal = "";
    }

    var subTeamInputVal = $("#subTeamInput").val();

    var priorityInputVal = $("#priorityInput option:selected").text();
    if (priorityInputVal !== "Select") {
    } else {
      priorityInputVal = "";
    }

    var customerNumberInputVal = $("#customerNumberInput").val();
    var customerNameInputVal = $("#customerNameInput").val();

    var descriptionInputVal = $("#descriptionInput").val();

    if (
      regionInputVal &&
      fromTeamInputVal &&
      companyCodeInputVal &&
      subjectInputVal &&
      assignedToInputVal &&
      subTeamInputVal &&
      priorityInputVal &&
      descriptionInputVal
    ) {
      addItemToList(
        regionInputVal,
        fromTeamInputVal,
        companyCodeInputVal,
        subjectInputVal,
        assignedToInputVal,
        subTeamInputVal,
        priorityInputVal,
        descriptionInputVal,
        customerNumberInputVal,
        customerNameInputVal
      );
    } else {
      var alertMessage =
        "Request form is incomplete. Please fill all mandatory columns!";
      BootstrapDialog.show({
        title: "Information",
        message: alertMessage,
        animate: false,
        buttons: [
          {
            label: "Close",
            action: function (dialogRef) {
              dialogRef.close();
            },
          },
        ],
      });
    }
  });

  $("#btnCancel").click(function () {
    var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
    var alertMessage = "Are you sure that you want to close this form";

    BootstrapDialog.show({
      title: "Information",
      message: alertMessage,
      animate: false,
      buttons: [
        {
          label: "Yes",
          action: function (dialogRef) {
            dialogRef.close();

            $(location).attr("href", url);
          },
        },
      ],
    });
  });

  $("#btnSave").click(function () {
    if (reAllocateRequest === false) {
      var now = new Date();

      var assignedToPersonInputVal = $(
        "#assignedToPersonInput option:selected"
      ).text();
      if (assignedToPersonInputVal !== "Select") {
      } else {
        assignedToPersonInputVal = "";
      }

      if (needToReassign === true) {
        var regionInputVal = $("#regionInput option:selected").text();
        if (regionInputVal !== "Select") {
        } else {
          regionInputVal = "";
        }

        var fromTeamInputVal = $("#fromTeamInput option:selected").text();
        if (fromTeamInputVal !== "Select") {
        } else {
          fromTeamInputVal = "";
        }

        var companyCodeInputVal = $("#companyCodeInput option:selected").text();
        if (companyCodeInputVal !== "Select") {
        } else {
          companyCodeInputVal = "";
        }
        var subjectInputVal = $("#subjectInput").val();
        var assignedToInputVal = $("#assignedToInput option:selected").text();
        if (assignedToInputVal !== "Select") {
        } else {
          assignedToInputVal = "";
        }

        var subTeamInputVal = $("#subTeamInput").val();

        var priorityInputVal = $("#priorityInput option:selected").text();
        if (priorityInputVal !== "Select") {
        } else {
          priorityInputVal = "";
        }

        var customerNumberInputVal = $("#customerNumberInput").val();
        var customerNameInputVal = $("#customerNameInput").val();

        var descriptionInputVal = $("#descriptionInput").val();

        if (
          regionInputVal &&
          fromTeamInputVal &&
          companyCodeInputVal &&
          subjectInputVal &&
          assignedToInputVal &&
          subTeamInputVal &&
          priorityInputVal &&
          descriptionInputVal
        ) {
          var approvalDetails = [];
          var now = new Date();
          currentDateTime = getDateTime(now);

          var approvalSectionDetails;

          var myTab = document.getElementById("tblHierarchyDetails");

          for (i = 1; i < myTab.rows.length; i++) {
            var hierarchy1 = "";
            var actionName = "";
            var date = "";
            var hierarchy2 = "";
            var status = "";
            var comments = "";

            var objCells = myTab.rows.item(i).cells;

            for (var j = 0; j < objCells.length; j++) {
              if (j == 0) {
                hierarchy1 = objCells.item(j).innerHTML;
              }
              if (j == 1) {
                actionName = objCells.item(j).innerHTML;
              }
              if (j == 2) {
                date = objCells.item(j).innerHTML;
              }
              if (j == 3) {
                hierarchy2 = objCells.item(j).innerHTML;
              }
              if (j == 4) {
                status = objCells.item(j).innerHTML;
              }
              if (j == 5) {
                comments = objCells.item(j).innerHTML;
              }

              // info.innerHTML = info.innerHTML + ' ' + objCells.item(j).innerHTML;
            }

            approvalSectionDetails = {
              hierarchy1: hierarchy1,
              name: actionName,
              date: date,
              hierarchy2: hierarchy2,
              status: status,
              comments: comments,
            };
            approvalDetails.push(approvalSectionDetails);
          }
          var assignedToPersonInputVal = $(
            "#assignedToPersonInput option:selected"
          ).text();
          if (assignedToPersonInputVal !== "Select") {
          } else {
            assignedToPersonInputVal = "";
          }

          var approvalSectionDetailsNew = {
            hierarchy1: "Re-Assigned By",
            name: currentUserName,
            date: currentDateTime,
            hierarchy2:
              "Re-Assigned from - " +
              requestAssignedToGroup +
              " - To - " +
              assignedToInputVal,
            status: "Not Started",
            comments: "",
          };
          approvalDetails.push(approvalSectionDetailsNew);

          saveReassignedValues(
            regionInputVal,
            fromTeamInputVal,
            companyCodeInputVal,
            subjectInputVal,
            assignedToInputVal,
            subTeamInputVal,
            priorityInputVal,
            descriptionInputVal,
            customerNumberInputVal,
            customerNameInputVal,
            approvalDetails
          );
        } else {
          var alertMessage =
            "Request form is incomplete. Please fill all mandatory columns!";
          BootstrapDialog.show({
            title: "Information",
            message: alertMessage,
            animate: false,
            buttons: [
              {
                label: "Close",
                action: function (dialogRef) {
                  dialogRef.close();
                },
              },
            ],
          });
        }
      } else if (needToReassign === false) {
        var approvalDetails = [];
        var now = new Date();
        currentDateTime = getDateTime(now);

        var approvalSectionDetails;

        if (assignedToPersonInputVal) {
          var myTab = document.getElementById("tblHierarchyDetails");

          for (i = 1; i < myTab.rows.length; i++) {
            var hierarchy1 = "";
            var actionName = "";
            var date = "";
            var hierarchy2 = "";
            var status = "";
            var comments = "";

            var objCells = myTab.rows.item(i).cells;

            for (var j = 0; j < objCells.length; j++) {
              if (j == 0) {
                hierarchy1 = objCells.item(j).innerHTML;
              }
              if (j == 1) {
                actionName = objCells.item(j).innerHTML;
              }
              if (j == 2) {
                date = objCells.item(j).innerHTML;
              }
              if (j == 3) {
                hierarchy2 = objCells.item(j).innerHTML;
              }
              if (j == 4) {
                status = objCells.item(j).innerHTML;
              }
              if (j == 5) {
                comments = objCells.item(j).innerHTML;
              }

              // info.innerHTML = info.innerHTML + ' ' + objCells.item(j).innerHTML;
            }

            approvalSectionDetails = {
              hierarchy1: hierarchy1,
              name: actionName,
              date: date,
              hierarchy2: hierarchy2,
              status: status,
              comments: comments,
            };
            approvalDetails.push(approvalSectionDetails);
          }
          var assignedToPersonInputVal = $(
            "#assignedToPersonInput option:selected"
          ).text();
          if (assignedToPersonInputVal !== "Select") {
          } else {
            assignedToPersonInputVal = "";
          }

          var approvalSectionDetailsNew = {
            hierarchy1: "Assigned By",
            name: currentUserName,
            date: currentDateTime,
            hierarchy2: "Assigned To - " + assignedToPersonInputVal,
            status: "In Progress",
            comments: "",
          };
          approvalDetails.push(approvalSectionDetailsNew);

          //alert("approvalSectionDetails: "+ JSON.stringify(approvalDetails));
          saveAssignedToPerson(assignedToPersonInputVal, approvalDetails);
        } else {
          var alertMessage = "Please select Assigned To Person!";
          BootstrapDialog.show({
            title: "Information",
            message: alertMessage,
            animate: false,
            buttons: [
              {
                label: "Close",
                action: function (dialogRef) {
                  dialogRef.close();
                },
              },
            ],
          });
        }
      }

      if (needToDelegate === true) {
        var approvalDetails = [];
        var now = new Date();
        currentDateTime = getDateTime(now);

        var approvalSectionDetails;

        let assignedToPersonInputValNew = $(
          "#divAssignedToPersonInput option:selected"
        ).text();

        if (assignedToPersonInputValNew) {
          var myTab = document.getElementById("tblHierarchyDetails");

          for (i = 1; i < myTab.rows.length; i++) {
            var hierarchy1 = "";
            var actionName = "";
            var date = "";
            var hierarchy2 = "";
            var status = "";
            var comments = "";

            var objCells = myTab.rows.item(i).cells;

            for (var j = 0; j < objCells.length; j++) {
              if (j == 0) {
                hierarchy1 = objCells.item(j).innerHTML;
              }
              if (j == 1) {
                actionName = objCells.item(j).innerHTML;
              }
              if (j == 2) {
                date = objCells.item(j).innerHTML;
              }
              if (j == 3) {
                hierarchy2 = objCells.item(j).innerHTML;
              }
              if (j == 4) {
                status = objCells.item(j).innerHTML;
              }
              if (j == 5) {
                comments = objCells.item(j).innerHTML;
              }

              // info.innerHTML = info.innerHTML + ' ' + objCells.item(j).innerHTML;
            }

            approvalSectionDetails = {
              hierarchy1: hierarchy1,
              name: actionName,
              date: date,
              hierarchy2: hierarchy2,
              status: status,
              comments: comments,
            };
            approvalDetails.push(approvalSectionDetails);
          }
          var assignedToPersonInputVal = $(
            "#assignedToPersonInput option:selected"
          ).text();
          if (assignedToPersonInputVal !== "Select") {
          } else {
            assignedToPersonInputVal = "";
          }

          var delegatedAssignedToPersonInputVal = $(
            "#divAssignedToPersonInput option:selected"
          ).text();
          if (delegatedAssignedToPersonInputVal !== "Select") {
          } else {
            delegatedAssignedToPersonInputVal = "";
          }

          var approvalSectionDetailsNew = {
            hierarchy1: "Delegated By",
            name: currentUserName,
            date: currentDateTime,
            hierarchy2:
              "Delegated from - " +
              assignedToPersonInputVal +
              " - To - " +
              delegatedAssignedToPersonInputVal,
            status: "In Progress",
            comments: "",
          };
          approvalDetails.push(approvalSectionDetailsNew);

          //alert("approvalSectionDetails: "+ JSON.stringify(approvalDetails));
          saveAssignedToPerson(
            delegatedAssignedToPersonInputVal,
            approvalDetails
          );
        } else {
          var alertMessage = "Please select Assigned To Person!";
          BootstrapDialog.show({
            title: "Information",
            message: alertMessage,
            animate: false,
            buttons: [
              {
                label: "Close",
                action: function (dialogRef) {
                  dialogRef.close();
                },
              },
            ],
          });
        }
      }
    } else {
      if (reAllocateRequest === true) {
        var approvalDetails = [];
        var now = new Date();
        currentDateTime = getDateTime(now);

        var approvalSectionDetails;

        let reAllocatePersonVal = $(
          "#divReallocateRequestToInput option:selected"
        ).text();

        if (reAllocatePersonVal === "Select") {
          reAllocatePersonVal = "";
        }

        if (reAllocatePersonVal) {
          var myTab = document.getElementById("tblHierarchyDetails");

          for (i = 1; i < myTab.rows.length; i++) {
            var hierarchy1 = "";
            var actionName = "";
            var date = "";
            var hierarchy2 = "";
            var status = "";
            var comments = "";

            var objCells = myTab.rows.item(i).cells;

            for (var j = 0; j < objCells.length; j++) {
              if (j == 0) {
                hierarchy1 = objCells.item(j).innerHTML;
              }
              if (j == 1) {
                actionName = objCells.item(j).innerHTML;
              }
              if (j == 2) {
                date = objCells.item(j).innerHTML;
              }
              if (j == 3) {
                hierarchy2 = objCells.item(j).innerHTML;
              }
              if (j == 4) {
                status = objCells.item(j).innerHTML;
              }
              if (j == 5) {
                comments = objCells.item(j).innerHTML;
              }

              // info.innerHTML = info.innerHTML + ' ' + objCells.item(j).innerHTML;
            }

            approvalSectionDetails = {
              hierarchy1: hierarchy1,
              name: actionName,
              date: date,
              hierarchy2: hierarchy2,
              status: status,
              comments: comments,
            };
            approvalDetails.push(approvalSectionDetails);
          }
          var assignedToPersonInputVal = $(
            "#assignedToPersonInput option:selected"
          ).text();
          if (assignedToPersonInputVal !== "Select") {
          } else {
            assignedToPersonInputVal = "";
          }

          var createdByVal = $("#createByInput").val();

          var approvalSectionDetailsNew = {
            hierarchy1: "Re-Allocated By",
            name: currentUserName,
            date: currentDateTime,
            hierarchy2:
              "Re-Allocated from - " +
              createdByVal +
              " - To - " +
              reAllocatePersonVal,
            status: "Response Received",
            comments: "",
          };
          approvalDetails.push(approvalSectionDetailsNew);

          //alert("approvalSectionDetails: "+ JSON.stringify(approvalDetails));
          saveReAllocateRequestToPerson(reAllocatePersonVal, approvalDetails);
        } else {
          var alertMessage = "Please select Re-allocate Request To Person!";
          BootstrapDialog.show({
            title: "Information",
            message: alertMessage,
            animate: false,
            buttons: [
              {
                label: "Close",
                action: function (dialogRef) {
                  dialogRef.close();
                },
              },
            ],
          });
        }
      }
    }
  });

  $("#btnUpdate").click(function () {
    var responseInputVal = $("#responseInput").val();

    if (responseInputVal) {
      var approvalDetails = [];
      var now = new Date();
      currentDateTime = getDateTime(now);
      var approvalSectionDetails;

      var myTab = document.getElementById("tblHierarchyDetails");

      for (i = 1; i < myTab.rows.length; i++) {
        var hierarchy1 = "";
        var actionName = "";
        var date = "";
        var hierarchy2 = "";
        var status = "";
        var comments = "";

        var objCells = myTab.rows.item(i).cells;

        for (var j = 0; j < objCells.length; j++) {
          if (j == 0) {
            hierarchy1 = objCells.item(j).innerHTML;
          }
          if (j == 1) {
            actionName = objCells.item(j).innerHTML;
          }
          if (j == 2) {
            date = objCells.item(j).innerHTML;
          }
          if (j == 3) {
            hierarchy2 = objCells.item(j).innerHTML;
          }
          if (j == 4) {
            status = objCells.item(j).innerHTML;
          }
          if (j == 5) {
            comments = objCells.item(j).innerHTML;
          }

          // info.innerHTML = info.innerHTML + ' ' + objCells.item(j).innerHTML;
        }

        approvalSectionDetails = {
          hierarchy1: hierarchy1,
          name: actionName,
          date: date,
          hierarchy2: hierarchy2,
          status: status,
          comments: comments,
        };
        approvalDetails.push(approvalSectionDetails);
      }
      var hierarchyVal = "Responded By";
      if (statusRejectVal) {
        hierarchyVal = "Re-Responded By";
      }

      var approvalSectionDetailsNew = {
        hierarchy1: hierarchyVal,
        name: currentUserName,
        date: currentDateTime,
        hierarchy2: responseInputVal,
        status: "Response Received",
        comments: responseInputVal,
      };
      approvalDetails.push(approvalSectionDetailsNew);

      updateResponse(responseInputVal, approvalDetails);
    } else {
      var alertMessage = "Please enter response details!";
      BootstrapDialog.show({
        title: "Information",
        message: alertMessage,
        animate: false,
        buttons: [
          {
            label: "Close",
            action: function (dialogRef) {
              dialogRef.close();
            },
          },
        ],
      });
    }
  });

  $("#btnClose").click(function () {
    var closureCommentsVal = $("#requestClosureCommentsInput").val();
    if (closureCommentsVal) {
      var approvalDetails = [];
      var now = new Date();
      currentDateTime = getDateTime(now);
      var approvalSectionDetails;

      var myTab = document.getElementById("tblHierarchyDetails");

      for (i = 1; i < myTab.rows.length; i++) {
        var hierarchy1 = "";
        var actionName = "";
        var date = "";
        var hierarchy2 = "";
        var status = "";
        var comments = "";

        var objCells = myTab.rows.item(i).cells;

        for (var j = 0; j < objCells.length; j++) {
          if (j == 0) {
            hierarchy1 = objCells.item(j).innerHTML;
          }
          if (j == 1) {
            actionName = objCells.item(j).innerHTML;
          }
          if (j == 2) {
            date = objCells.item(j).innerHTML;
          }
          if (j == 3) {
            hierarchy2 = objCells.item(j).innerHTML;
          }
          if (j == 4) {
            status = objCells.item(j).innerHTML;
          }
          if (j == 5) {
            comments = objCells.item(j).innerHTML;
          }

          // info.innerHTML = info.innerHTML + ' ' + objCells.item(j).innerHTML;
        }

        approvalSectionDetails = {
          hierarchy1: hierarchy1,
          name: actionName,
          date: date,
          hierarchy2: hierarchy2,
          status: status,
          comments: comments,
        };
        approvalDetails.push(approvalSectionDetails);
      }

      var approvalSectionDetailsNew = {
        hierarchy1: "Closed By",
        name: currentUserName,
        date: currentDateTime,
        hierarchy2: closureCommentsVal,
        status: "Completed",
        comments: closureCommentsVal,
      };
      approvalDetails.push(approvalSectionDetailsNew);

      updateStatus("Completed", closureCommentsVal, approvalDetails);
    } else {
      var alertMessage = "Please enter request closure comments!";
      BootstrapDialog.show({
        title: "Information",
        message: alertMessage,
        animate: false,
        buttons: [
          {
            label: "Close",
            action: function (dialogRef) {
              dialogRef.close();
            },
          },
        ],
      });
    }
  });

  $("#btnReject").click(function () {
    var closureCommentsVal = $("#requestClosureCommentsInput").val();
    if (closureCommentsVal) {
      var approvalDetails = [];
      var now = new Date();
      currentDateTime = getDateTime(now);
      var approvalSectionDetails;

      var myTab = document.getElementById("tblHierarchyDetails");

      for (i = 1; i < myTab.rows.length; i++) {
        var hierarchy1 = "";
        var actionName = "";
        var date = "";
        var hierarchy2 = "";
        var status = "";
        var comments = "";

        var objCells = myTab.rows.item(i).cells;

        for (var j = 0; j < objCells.length; j++) {
          if (j == 0) {
            hierarchy1 = objCells.item(j).innerHTML;
          }
          if (j == 1) {
            actionName = objCells.item(j).innerHTML;
          }
          if (j == 2) {
            date = objCells.item(j).innerHTML;
          }
          if (j == 3) {
            hierarchy2 = objCells.item(j).innerHTML;
          }
          if (j == 4) {
            status = objCells.item(j).innerHTML;
          }
          if (j == 5) {
            comments = objCells.item(j).innerHTML;
          }

          // info.innerHTML = info.innerHTML + ' ' + objCells.item(j).innerHTML;
        }

        approvalSectionDetails = {
          hierarchy1: hierarchy1,
          name: actionName,
          date: date,
          hierarchy2: hierarchy2,
          status: status,
          comments: comments,
        };
        approvalDetails.push(approvalSectionDetails);
      }

      var approvalSectionDetailsNew = {
        hierarchy1: "Rejected By",
        name: currentUserName,
        date: currentDateTime,
        hierarchy2: closureCommentsVal,
        status: "Rejected",
        comments: closureCommentsVal,
      };
      approvalDetails.push(approvalSectionDetailsNew);

      updateRejectedStatus("Rejected", closureCommentsVal, approvalDetails);
    } else {
      var alertMessage = "Please enter request closure comments!";
      BootstrapDialog.show({
        title: "Information",
        message: alertMessage,
        animate: false,
        buttons: [
          {
            label: "Close",
            action: function (dialogRef) {
              dialogRef.close();
            },
          },
        ],
      });
    }
  });

  function saveReassignedValues(
    regionInputVal,
    fromTeamInputVal,
    companyCodeInputVal,
    subjectInputVal,
    assignedToInputVal,
    subTeamInputVal,
    priorityInputVal,
    descriptionInputVal,
    customerNumberInputVal,
    customerNameInputVal,
    approvalDetails
  ) {
    try {
      var loginuserid = _spPageContextInfo.userId;
      var now = new Date();
      currentDateTime = getDateTime(now);
      var queryUrl =
        siteUrl +
        "/_api/web/lists/getbytitle('Email Management')/items('" +
        queryStrVal +
        "')";

      $.ajax({
        url: queryUrl, // list item ID
        type: "POST",
        async: false,
        data: JSON.stringify({
          __metadata: {
            type: "SP.Data.EmailManagementListItem",
          },
          Title: regionInputVal,
          FromTeam: fromTeamInputVal,
          FromCompanyCode: companyCodeInputVal,
          Subject: subjectInputVal,
          AssignedTo: assignedToInputVal,
          SubTeam: subTeamInputVal,
          Priority: priorityInputVal,
          CustomerNumber: customerNumberInputVal,
          CustomerName: customerNameInputVal,
          Description: descriptionInputVal,
          RequestCreatedGroup: currentUserGroupName,
          Status: "Not Started",
          AssignedToPerson: "",
          Response: "",
          ApprovalDetails: JSON.stringify(approvalDetails),
          ReAllocateRequestTo: "",
          ReAllocateRequest: "",
        }),
        headers: {
          Accept: "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose",
          "X-RequestDigest": $("#__REQUESTDIGEST").val(),
          "IF-MATCH": "*",
          "X-HTTP-Method": "MERGE",
        },
        success: onQuerySuccessReassign,
        error: onQueryFailureReassign,
      });
    } catch (ex) {
      console.log("Exception" + ex.message);
      alert("Exception" + ex.message);
    }
  }
  function onQuerySuccessReassign() {
    if (queryStrVal > 0) {
      uploadFiles(
        "emailAttachmentsResponse",
        "Email Management New",
        queryStrVal
      );
    }

    var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
    var alertMessage = "Request reassign details are saved successfully.";
    BootstrapDialog.show({
      title: "Information",
      message: alertMessage,
      animate: false,
      buttons: [
        {
          label: "Close",
          action: function (dialogRef) {
            dialogRef.close();
            $(location).attr("href", url);
          },
        },
      ],
    });
  }
  function onQueryFailureReassign(error) {
    alert(JSON.stringify(error));
  }

  $("#needToReassign").click(function () {
    if ($(this).is(":checked")) {
      var alertMessage = "Do you want to proceed";

      BootstrapDialog.show({
        title: "Information",
        message: alertMessage,
        animate: false,
        buttons: [
          {
            label: "Yes",
            action: function (dialogRef) {
              dialogRef.close();
              $("#btnClose").hide();
              $("#btnSave").show();
              $("#btnReject").hide();

              $("#assignedToPersonNewInput").val("");
              $("#responseInput").val("");
              $("#requestClosureCommentsInput").val("");

              $("#chkReAllocateRequest").prop("disabled", false);
              $("#lblReAllocateRequestTo").hide();
              $("#divReallocateRequestToInput").hide();
              document.getElementById("chkReAllocateRequest").checked = false;

              enableReassignColumns();
              needToReassign = true;
              $("#needToReassign").prop("disabled", true);
              $("#chkReAllocateRequest").prop("disabled", true);

              //$(location).attr("href", url);
            },
          },
          {
            label: "No",
            action: function (dialogRef) {
              dialogRef.close();
              $("#btnClose").show();
              $("#btnSave").hide();
              $("#btnReject").show();
              needToReassign = false;
              disableReassignColumns();
              document.getElementById("needToReassign").checked = false;
              //document.getElementById("chkReAllocateRequest").checked = false;
              $("#chkReAllocateRequest").prop("disabled", false);
            },
          },
        ],
      });
    } else {
      // $("#btnClose").show();
      // $("#btnSave").hide();
      // $("#btnReject").show();
      // needToReassign = false;
      // disableReassignColumns();
    }
  });

  $("#needToDelegate").click(function () {
    if ($(this).is(":checked")) {
      var alertMessage = "Do you want to proceed";

      BootstrapDialog.show({
        title: "Information",
        message: alertMessage,
        animate: false,
        buttons: [
          {
            label: "Yes",
            action: function (dialogRef) {
              dialogRef.close();
              $("#btnClose").hide();
              $("#btnUpdate").hide();
              $("#btnReject").hide();
              $("#btnSave").show();
              $("#btnReject").hide();

              $("#assignedToPersonNewInput").prop("disabled", false);
              $("#responseInput").prop("disabled", true);
              $("#emailAttachmentsResponse").prop("disabled", true);

              var assignedToInputVal = $(
                "#assignedToInput option:selected"
              ).text();
              if (assignedToInputVal !== "Select") {
              } else {
                assignedToInputVal = "";
              }

              $("#assignedToPersonNewInput").hide();
              $("#divAssignedToPersonInput").show();

              getAllUsersFromSiteGroupNew(assignedToInputVal);

              //enableReassignColumns();
              needToDelegate = true;
              $("#needToDelegate").prop("disabled", true);
            },
          },
          {
            label: "No",
            action: function (dialogRef) {
              dialogRef.close();
              $("#btnClose").hide();
              $("#btnUpdate").show();
              $("#btnReject").hide();
              $("#btnSave").hide();
              $("#btnReject").hide();
              $("#assignedToPersonNewInput").prop("disabled", true);
              $("#responseInput").prop("disabled", true);
              $("#needToDelegate").prop("disabled", false);
              needToDelegate = false;
              document.getElementById("needToDelegate").checked = false;
            },
          },
        ],
      });
    } else {
      // $("#btnClose").hide();
      // $("#btnUpdate").show();
      // $("#btnReject").hide();
      // $("#btnSave").hide();
      // $("#btnReject").hide();
      // $("#assignedToPersonNewInput").prop("disabled", true);
      // $("#responseInput").prop("disabled", false);
      // needToDelegate = false;
      //disableReassignColumns();
    }
  });

  $("#chkReAllocateRequest").click(function () {
    if ($(this).is(":checked")) {
      var alertMessage = "Do you want to proceed";

      BootstrapDialog.show({
        title: "Information",
        message: alertMessage,
        animate: false,
        buttons: [
          {
            label: "Yes",
            action: function (dialogRef) {
              dialogRef.close();
              $("#btnSave").show();
              $("#btnClose").hide();
              $("#btnReject").hide();

              var assignedFromInputVal = $(
                "#fromTeamInput option:selected"
              ).text();
              if (assignedFromInputVal !== "Select") {
              } else {
                assignedFromInputVal = "";
              }

              getAllUsersTeamFrom(assignedFromInputVal);

              $("#lblReAllocateRequestTo").show();
              $("#divReallocateRequestToInput").show();
              reAllocateRequest = true;
              document.getElementById("needToReassign").checked = false;
              $("#needToReassign").prop("disabled", true);
              $("#chkReAllocateRequest").prop("disabled", true);
            },
          },
          {
            label: "No",
            action: function (dialogRef) {
              dialogRef.close();
              $("#lblReAllocateRequestTo").hide();
              $("#divReallocateRequestToInput").hide();

              $("#btnClose").hide();
              $("#btnUpdate").hide();
              $("#btnReject").hide();
              $("#btnSave").hide();
              $("#btnReject").hide();
              $("#assignedToPersonNewInput").prop("disabled", true);
              $("#responseInput").prop("disabled", true);
              $("#needToReassign").prop("disabled", false);
              $("#chkReAllocateRequest").prop("disabled", false);
              document.getElementById("chkReAllocateRequest").checked = false;
              reAllocateRequest = false;
            },
          },
        ],
      });
    } else {
      // $("#lblReAllocateRequestTo").hide();
      // $("#divReallocateRequestToInput").hide();
      // $("#btnClose").hide();
      // $("#btnUpdate").hide();
      // $("#btnReject").hide();
      // $("#btnSave").hide();
      // $("#btnReject").hide();
      // $("#assignedToPersonNewInput").prop("disabled", true);
      // $("#responseInput").prop("disabled", true);
      // reAllocateRequest = false;
      //disableReassignColumns();
    }
  });
});

function updateStatus(statusVal, closureCommentsVal, approvalDetails) {
  try {
    var currentDate = new Date();
    var currentDateFormatted = getDateTime(currentDate);
    var queryUrl =
      siteUrl +
      "/_api/web/lists/getbytitle('Email Management')/items('" +
      queryStrVal +
      "')";

    $.ajax({
      url: queryUrl, // list item ID
      type: "POST",
      async: false,
      data: JSON.stringify({
        __metadata: {
          type: "SP.Data.EmailManagementListItem",
        },
        Status: statusVal,
        RequestClosedDate: currentDateFormatted,
        RequestClosedBy: currentUserName,
        RequestClosureComments: closureCommentsVal,
        ApprovalDetails: JSON.stringify(approvalDetails),
      }),
      headers: {
        Accept: "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
        "IF-MATCH": "*",
        "X-HTTP-Method": "MERGE",
      },
      success: onQuerySuccessClose,
      error: onQueryFailureClose,
    });
  } catch (ex) {
    console.log("Exception" + ex.message);
    alert("Exception" + ex.message);
  }
}
function onQuerySuccessClose() {
  var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
  var alertMessage = "Request closed successfully.";
  BootstrapDialog.show({
    title: "Information",
    message: alertMessage,
    animate: false,
    buttons: [
      {
        label: "Close",
        action: function (dialogRef) {
          dialogRef.close();
          $(location).attr("href", url);
        },
      },
    ],
  });
}
function onQueryFailureClose(error) {
  alert(JSON.stringify(error));
}

function updateRejectedStatus(statusVal, closureCommentsVal, approvalDetails) {
  try {
    var currentDate = new Date();
    var currentDateFormatted = getFormattedDate(currentDate);
    var queryUrl =
      siteUrl +
      "/_api/web/lists/getbytitle('Email Management')/items('" +
      queryStrVal +
      "')";

    $.ajax({
      url: queryUrl, // list item ID
      type: "POST",
      async: false,
      data: JSON.stringify({
        __metadata: {
          type: "SP.Data.EmailManagementListItem",
        },
        Status: statusVal,
        RequestClosedDate: currentDateFormatted,
        RequestClosedBy: currentUserName,
        RequestClosureComments: closureCommentsVal,
        ApprovalDetails: JSON.stringify(approvalDetails),
      }),
      headers: {
        Accept: "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
        "IF-MATCH": "*",
        "X-HTTP-Method": "MERGE",
      },
      success: onQuerySuccessReject,
      error: onQueryFailureReject,
    });
  } catch (ex) {
    console.log("Exception" + ex.message);
    alert("Exception" + ex.message);
  }
}
function onQuerySuccessReject() {
  var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
  var alertMessage = "Request rejected successfully.";
  BootstrapDialog.show({
    title: "Information",
    message: alertMessage,
    animate: false,
    buttons: [
      {
        label: "Close",
        action: function (dialogRef) {
          dialogRef.close();
          $(location).attr("href", url);
        },
      },
    ],
  });
}
function onQueryFailureReject(error) {
  alert(JSON.stringify(error));
}

function onQuerySuccessApprove() {
  if (queryStrVal > 0) {
    uploadFiles(
      "emailAttachmentsResponse",
      "Email Management Response",
      queryStrVal
    );
  }

  var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
  var alertMessage = "Request closed successfully.";
  BootstrapDialog.show({
    title: "Information",
    message: alertMessage,
    animate: false,
    buttons: [
      {
        label: "Close",
        action: function (dialogRef) {
          dialogRef.close();
          $(location).attr("href", url);
        },
      },
    ],
  });
}
function onQueryFailureApprove(error) {
  alert(JSON.stringify(error));
}

function updateResponse(responseInputVal, approvalDetails) {
  try {
    var loginuserid = _spPageContextInfo.userId;
    var queryUrl =
      siteUrl +
      "/_api/web/lists/getbytitle('Email Management')/items('" +
      queryStrVal +
      "')";

    $.ajax({
      url: queryUrl, // list item ID
      type: "POST",
      async: false,
      data: JSON.stringify({
        __metadata: {
          type: "SP.Data.EmailManagementListItem",
        },
        Response: responseInputVal,
        Status: "Response Received",
        ApprovalDetails: JSON.stringify(approvalDetails),
        RequestClosureComments: "",
      }),
      headers: {
        Accept: "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
        "IF-MATCH": "*",
        "X-HTTP-Method": "MERGE",
      },
      success: onQuerySuccessUpdate,
      error: onQueryFailureUpdate,
    });
  } catch (ex) {
    console.log("Exception" + ex.message);
    alert("Exception" + ex.message);
  }
}
function onQuerySuccessUpdate() {
  if (queryStrVal > 0) {
    uploadFiles(
      "emailAttachmentsResponse",
      "Email Management Response",
      queryStrVal
    );
  }

  var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
  var alertMessage = "Response details are saved successfully.";
  BootstrapDialog.show({
    title: "Information",
    message: alertMessage,
    animate: false,
    buttons: [
      {
        label: "Close",
        action: function (dialogRef) {
          dialogRef.close();
          $(location).attr("href", url);
        },
      },
    ],
  });
}
function onQueryFailureUpdate(error) {
  alert(JSON.stringify(error));
}

function saveAssignedToPerson(assignedToPersonInputVal, approvalDetails) {
  try {
    var loginuserid = _spPageContextInfo.userId;
    var queryUrl =
      siteUrl +
      "/_api/web/lists/getbytitle('Email Management')/items('" +
      queryStrVal +
      "')";

    $.ajax({
      url: queryUrl, // list item ID
      type: "POST",
      async: false,
      data: JSON.stringify({
        __metadata: {
          type: "SP.Data.EmailManagementListItem",
        },
        AssignedToPerson: assignedToPersonInputVal,
        Status: "In Progress",
        ApprovalDetails: JSON.stringify(approvalDetails),
      }),
      headers: {
        Accept: "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
        "IF-MATCH": "*",
        "X-HTTP-Method": "MERGE",
      },
      success: onQuerySuccessSave,
      error: onQueryFailureSave,
    });
  } catch (ex) {
    console.log("Exception" + ex.message);
    alert("Exception" + ex.message);
  }
}
function onQuerySuccessSave() {
  // if(queryStrVal > 0){
  //     uploadFiles("serviceDeskAttachmentsNew", "Service Desk New", queryStrVal);
  // }

  var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
  var alertMessage = "Assigned To Person saved successfully.";
  BootstrapDialog.show({
    title: "Information",
    message: alertMessage,
    animate: false,
    buttons: [
      {
        label: "Close",
        action: function (dialogRef) {
          dialogRef.close();
          $(location).attr("href", url);
        },
      },
    ],
  });
}
function onQueryFailureSave(error) {
  alert(JSON.stringify(error));
}

function saveReAllocateRequestToPerson(reAllocatePersonVal, approvalDetails) {
  try {
    var loginuserid = _spPageContextInfo.userId;
    var queryUrl =
      siteUrl +
      "/_api/web/lists/getbytitle('Email Management')/items('" +
      queryStrVal +
      "')";

    $.ajax({
      url: queryUrl, // list item ID
      type: "POST",
      async: false,
      data: JSON.stringify({
        __metadata: {
          type: "SP.Data.EmailManagementListItem",
        },
        ReAllocateRequest: "Yes",
        ReAllocateRequestTo: reAllocatePersonVal,
        Status: "Response Received",
        ApprovalDetails: JSON.stringify(approvalDetails),
      }),
      headers: {
        Accept: "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
        "IF-MATCH": "*",
        "X-HTTP-Method": "MERGE",
      },
      success: onQuerySuccessReAllocate,
      error: onQueryFailureReAllocate,
    });
  } catch (ex) {
    console.log("Exception" + ex.message);
    alert("Exception" + ex.message);
  }
}
function onQuerySuccessReAllocate() {
  // if(queryStrVal > 0){
  //     uploadFiles("serviceDeskAttachmentsNew", "Service Desk New", queryStrVal);
  // }

  var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
  var alertMessage = "Re-Allocate Request To Person saved successfully.";
  BootstrapDialog.show({
    title: "Information",
    message: alertMessage,
    animate: false,
    buttons: [
      {
        label: "Close",
        action: function (dialogRef) {
          dialogRef.close();
          $(location).attr("href", url);
        },
      },
    ],
  });
}
function onQueryFailureReAllocate(error) {
  alert(JSON.stringify(error));
}

function disableColumns() {
  $("#divResponse").hide();
  $("#btnSave").hide();
  $("#btnUpdate").hide();
  $("#divResponseDetails").hide();
  $("#responseInput").prop("disabled", true);
  $("#regionInputNew").prop("disabled", true);
  $("#fromTeamInputNew").prop("disabled", true);
  $("#companyCodeInputNew").prop("disabled", true);
  $("#assignedToInputNew").prop("disabled", true);
  $("#priorityInput").prop("disabled", true);
  $("#emailAttachmentsNew").hide();
  $("#btnClose").hide();
  $("#btnReject").hide();
  $("#divRequestClosedByDetails").hide();
  $("#requestClosureCommentsInput").prop("disabled", true);
  $("#chkReAllocateRequest").prop("disabled", true);

  $("#requestClosureComments").hide();
  $("#divNeedToDelegate").hide();
  $("#lblReAllocateRequestTo").hide();
  $("#divReallocateRequestToInput").hide();

  $("#txtReAllocateRequestToInput").hide();
}

function enableReassignColumns() {
  $("#responseInput").prop("disabled", false);
  $("#regionInputNew").prop("disabled", false);
  $("#fromTeamInputNew").prop("disabled", false);
  $("#companyCodeInputNew").prop("disabled", false);
  $("#assignedToInputNew").prop("disabled", false);
  $("#priorityInput").prop("disabled", false);
  $("#subjectInput").prop("disabled", false);
  $("#customerNumberInput").prop("disabled", false);
  $("#customerNameInput").prop("disabled", false);
  $("#descriptionInput").prop("disabled", false);

  $("#responseInput").prop("disabled", true);

  $("#emailAttachmentsNew").show();

  $("#requestClosureCommentsInput").prop("disabled", true);
}

function disableReassignColumns() {
  $("#responseInput").prop("disabled", true);
  $("#regionInputNew").prop("disabled", true);
  $("#fromTeamInputNew").prop("disabled", true);
  $("#companyCodeInputNew").prop("disabled", true);
  $("#assignedToInputNew").prop("disabled", true);
  $("#priorityInput").prop("disabled", true);
  $("#subjectInput").prop("disabled", true);
  $("#customerNumberInput").prop("disabled", true);
  $("#customerNameInput").prop("disabled", true);
  $("#descriptionInput").prop("disabled", true);

  $("#responseInput").prop("disabled", false);

  $("#emailAttachmentsNew").hide();

  $("#requestClosureCommentsInput").prop("disabled", false);
}

function getQueryStrVal() {
  var hashes = window.location.href
    .slice(window.location.href.indexOf("?") + 1)
    .split("&");
  for (var i = 0; i < hashes.length; i++) {
    hash = hashes[i].split("=");
    queryStrVal.push(hash[1]);
    queryStrVal[hash[0]] = hash[1];
  }
  if (queryStrVal[0] !== undefined && queryStrVal[0].length > 0) {
    getEmailManagementDetails();
  } else {
  }
}
function getFormattedDate(sDate) {
  var date = moment.utc(sDate).format("MM/DD/YYYY");
  var dt = moment(date).date();
  var month = moment(date).month() + 1;
  var year = moment(date).year();

  if (dt < 10) {
    dt = "0" + dt;
  }
  if (month < 10) {
    month = "0" + month;
  }
  var fDate = month + "/" + dt + "/" + year;
  return fDate;
}

function getEmailManagementDetails() {
  var bankURL =
    siteUrl +
    "/_api/web/lists/getbytitle('Email Management')/items?$select=ID,Title,FromTeam,FromCompanyCode,Subject,AssignedTo,SubTeam,Priority,CustomerNumber,CustomerName,Description,Status,Created,Author/Title,RequestCreatedGroup,AssignedToPerson,Response,RequestClosedBy,RequestClosedDate,RequestClosureComments,ApprovalDetails,ReAllocateRequest,ReAllocateRequestTo&$expand=Author/Title&$filter=(ID eq '" +
    queryStrVal +
    "')&$orderby=ID asc&$top=1000";

  return $.ajax({
    url: bankURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length; //get items count
      var isMember = false;
      var hierarchyDetailsBody = [];
      $.each(data.d.results, function (index, item) {
        if (item.ApprovalDetails) {
          hierarchyDetailsBody.push(JSON.parse(item.ApprovalDetails));
          if (hierarchyDetailsBody.length > 0) {
            $.each(hierarchyDetailsBody, function (key, value) {
              console.log("hierarchy value: " + JSON.stringify(value));

              for (var e = 0; e < value.length; e++) {
                $("#tbody").append(`<tr>
                    <td>${value[e].hierarchy1}</td>
                    <td>${value[e].name}</td>
                    <td>${value[e].date}</td>
                    <td>${value[e].hierarchy2}</td>
                    <td>${value[e].status}</td>
                    <td>${value[e].comments}</td>
                </tr>`);
              }
            });
          }
        }

        if (item.Title) {
          $('#regionInput option[value="' + item.Title + '"]').prop(
            "selected",
            true
          );
        }
        if (item.FromTeam) {
          $('#fromTeamInput option[value="' + item.FromTeam + '"]').prop(
            "selected",
            true
          );
        }
        // alert("item.FromCompanyCode: "+ item.FromCompanyCode)
        if (item.FromCompanyCode) {
          $(
            '#companyCodeInput option[value="' + item.FromCompanyCode + '"]'
          ).prop("selected", true);
        }
        if (item.Subject) {
          $("#subjectInput").val(item.Subject);
        }

        if (item.AssignedTo) {
          requestAssignedToGroup = item.AssignedTo;
          $('#assignedToInput option[value="' + item.AssignedTo + '"]').prop(
            "selected",
            true
          );
          isMember = isMemberOfGroup(item.AssignedTo);
          if (isMember) {
            $("#divResponse").show();
            $("#btnSave").show();
            if (item.Status === "In Progress") {
              $("#divNeedToDelegate").show();
              $("#btnUpdate").show();
              $("#emailAttachmentsResponse").prop("disabled", false);
            } else {
              $("#divNeedToDelegate").hide();
            }
          }
          getAllUsersFromSiteGroup(item.AssignedTo);
        }
        if (item.SubTeam) {
          $("#subTeamInput").val(item.SubTeam);
        }
        if (item.Priority) {
          $('#priorityInput option[value="' + item.Priority + '"]').prop(
            "selected",
            true
          );
        }
        if (item.CustomerNumber) {
          $("#customerNumberInput").val(item.CustomerNumber);
        }
        if (item.CustomerName) {
          $("#customerNameInput").val(item.CustomerName);
        }
        if (item.Description) {
          $("#descriptionInput").val(item.Description);
        }
        if (item.Author) {
          $("#createByInput").val(item.Author.Title);
        }
        if (item.RequestCreatedGroup) {
          $("#createdByGroupInput").val(item.RequestCreatedGroup);
        }
        if (item.Created) {
          var createdVal = getDateTime(item.Created);
          $("#createdDateTimeInput").val(createdVal);
        }

        if (item.RequestClosedDate) {
          var requestClosedDateVal = getDateTime(item.RequestClosedDate);
          $("#requestClosedDateTimeInput").val(requestClosedDateVal);
        }
        if (item.RequestClosedBy) {
          $("#requestClosedByInput").val(item.RequestClosedBy);
        }
        if (item.AssignedToPerson) {
          $(
            '#assignedToPersonInput option[value="' +
              item.AssignedToPerson +
              '"]'
          ).prop("selected", true);

          $("#assignedToPersonInputNew").prop("disabled", true);
          $("#assignedToPersonNewInput").val(item.AssignedToPerson);
        }
        if (item.Response) {
          $("#responseInput").val(item.Response);
        }
        if (item.RequestClosureComments) {
          $("#requestClosureCommentsInput").val(item.RequestClosureComments);
        }

        if (item.Status && item.Status == "Not Started") {
          getCurrentUserGroupNameNew("Email " + item.AssignedTo);
          isAdmin = isMemberOfGroup("Admins");
          isSupervisor = isMemberOfGroup("Managers-or-Supervisors");
          // alert("isAssignedToGroupUser :" + isAssignedToGroupUser);
          if (isAssignedToGroupUser || isAdmin || isSupervisor) {
            $("#divResponse").show();
            $("#divResponseDetails").hide();
            $("#btnSave").show();
            $("#btnUpdate").hide();
          } else {
            $("#divResponse").hide();
            $("#divResponseDetails").hide();
            $("#btnSave").hide();
            $("#btnUpdate").hide();
          }
        } else if (item.Status && item.Status == "In Progress") {
          $("#divResponse").hide();
          $("#divResponseDetails").show();

          $("#btnSave").hide();
          $("#btnUpdate").hide();
          $("#emailAttachmentsResponse").prop("disabled", true);

          if (currentUserName === item.AssignedToPerson || isAdmin) {
            $("#divNeedToDelegate").show();
            $("#responseInput").prop("disabled", false);
            $("#emailAttachmentsResponse").prop("disabled", false);
            $("#btnUpdate").show();
          } else {
            $("#divNeedToDelegate").false();
            $("#responseInput").prop("disabled", true);
            $("#emailAttachmentsResponse").prop("disabled", true);
          }
        } else if (item.Status && item.Status == "Response Received") {
          if (
            currentUserName === item.AssignedToPerson ||
            currentUserName === item.ReAllocateRequestTo
          ) {
            if (item.ReAllocateRequest === "Yes" && item.ReAllocateRequestTo) {
              $("#lblReAllocateRequestTo").show();
              $("#divReallocateRequestToInput").hide();
              $("#txtReAllocateRequestToInput").show();
              document.getElementById("chkReAllocateRequest").checked = true;

              $("#lblReAllocateRequestTo").show();
              $("#chkReAllocateRequest").prop("disabled", true);
              $("#txtReAllocateRequestToInput").val(item.ReAllocateRequestTo);
            } else {
              $("#chkReAllocateRequest").prop("disabled", false);
              $("#lblReAllocateRequestTo").hide();
              $("#divReallocateRequestToInput").hide();
            }

            $("#divResponse").hide();
            $("#divResponseDetails").show();

            $("#btnSave").hide();
            $("#btnUpdate").hide();
            $("#responseInput").prop("disabled", true);
            $("#emailAttachmentsResponse").hide();

            $("#btnClose").show();
            $("#btnReject").show();
            $("#divRequestClosedByDetails").hide();
            $("#requestClosureComments").show();

            $("#requestClosureCommentsInput").prop("disabled", false);

            getAttachments(
              queryStrVal,
              "Email Management Response",
              "emailAttachmentsResponseGrid"
            );
          } else {
            if (isMember) {
              if (
                item.ReAllocateRequest === "Yes" &&
                item.ReAllocateRequestTo
              ) {
                $("#lblReAllocateRequestTo").show();
                $("#divReallocateRequestToInput").hide();
                $("#txtReAllocateRequestToInput").show();
                document.getElementById("chkReAllocateRequest").checked = true;
                $("#chkReAllocateRequest").prop("disabled", false);
                $("#txtReAllocateRequestToInput").val(item.ReAllocateRequestTo);
              } else {
              }

              $("#btnSave").hide();

              $("#divResponse").hide();
              $("#divResponseDetails").show();

              $("#btnSave").hide();
              $("#btnUpdate").hide();
              $("#responseInput").prop("disabled", true);
              $("#emailAttachmentsResponse").hide();

              $("#btnClose").hide();
              $("#btnReject").hide();
              $("#divRequestClosedByDetails").hide();
              $("#requestClosureComments").show();

              $("#requestClosureCommentsInput").prop("disabled", true);
              $("#needToReassign").prop("disabled", true);

              // $("#lblReAllocateRequestTo").show();
              // $("#txtReAllocateRequestTo").show();
              getAttachments(
                queryStrVal,
                "Email Management Response",
                "emailAttachmentsResponseGrid"
              );
            }

            // $("#requestClosureComments").show();
            // $("#divResponseDetails").show();
          }
        } else if (item.Status && item.Status == "Rejected") {
          if (currentUserName === item.AssignedToPerson) {
            statusRejectVal = item.Status;
            $("#divResponse").show();
            $("#divResponseDetails").show();

            $("#btnSave").hide();
            $("#btnUpdate").show();
            $("#responseInput").prop("disabled", false);
            $("#emailAttachmentsResponse").show();

            $("#btnClose").hide();
            $("#btnReject").hide();
            $("#divRequestClosedByDetails").hide();
            $("#requestClosureComments").show();

            $("#needToReassign").prop("disabled", true);
            $("#requestClosureCommentsInput").prop("disabled", true);

            getAttachments(
              queryStrVal,
              "Email Management Response",
              "emailAttachmentsResponseGrid"
            );
          } else {
            $("#btnSave").hide();
            // $("#requestClosureComments").show();
            // $("#divResponseDetails").show();
          }
        } else if (item.Status && item.Status == "Completed") {
          $("#divResponse").hide();
          $("#divResponseDetails").show();

          $("#btnSave").hide();
          $("#btnUpdate").hide();
          $("#responseInput").prop("disabled", true);
          $("#needToReassign").prop("disabled", true);
          $("#emailAttachmentsResponse").hide();

          $("#requestClosureComments").show();

          $("#btnClose").hide();
          $("#divRequestClosedByDetails").show();

          getAttachments(
            queryStrVal,
            "Email Management Response",
            "emailAttachmentsResponseGrid"
          );
        }
        getAttachments(
          queryStrVal,
          "Email Management New",
          "emailAttachmentsNewGrid"
        );
      });
      //console.log("emailManagementDetails: "+ JSON.stringify(emailManagementDetails));
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}

function getDateTime(date) {
  var now = new Date(date);
  // now = now.toDateString();
  // now = now.toLocaleTimeString();

  console.log("now: " + now);
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var day = now.getDate();
  var hour = now.getHours();
  var minute = now.getMinutes();
  var second = now.getSeconds().toFixed(2);

  if (month.toString().length == 1) {
    month = "0" + month;
  }
  if (day.toString().length == 1) {
    day = "0" + day;
  }
  if (hour.toString().length == 1) {
    hour = "0" + hour;
  }
  if (minute.toString().length == 1) {
    minute = "0" + minute;
  }
  if (second.toString().length == 1) {
    second = "0" + second;
  }
  var dateTime = month + "/" + day + "/" + year + " " + hour + ":" + minute;
  // console.log(dateTime);
  // alert("cashApplicationDate: " + dateTime)
  // requestSubmittedDateTime = dateTime;
  return dateTime;
}

function isMemberOfGroup(groupName) {
  var groupNameVal = "Email ";
  groupNameVal += groupName;
  try {
    var isMember = false;
    $().SPServices({
      operation: "GetGroupCollectionFromUser",
      webURL: _spPageContextInfo.webServerRelativeUrl,
      userLoginName: $().SPServices.SPGetCurrentUser({
        webURL: _spPageContextInfo.webServerRelativeUrl,
        fieldName: "Name",
      }),
      async: false,
      completefunc: function (xData, Status) {
        if (
          $(xData.responseXML).find("Group[Name='" + groupNameVal + "']")
            .length == 1
        ) {
          isMember = true;
        }
      },
    });
  } catch (err) {}
  return isMember;
}

function getAllUsersFromSiteGroup(assignedToGroupName) {
  var groupName = "Email ";
  groupName += assignedToGroupName;
  $.ajax({
    url:
      siteUrl +
      "/_api/web/sitegroups/?$filter=(Title eq '" +
      groupName +
      "')&$top=1",
    type: "GET",
    async: false,
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data, status, xhr) {
      getSiteUsersByGroupId(data.d.results[0].Id);
    },
    error: function (xhr, status, error) {
      console.log("Failed");
    },
  });
}

function getSiteUsersByGroupId(GroupId) {
  $("#assignedToPersonInputNew").remove();
  $.ajax({
    url: siteUrl + "/_api/web/sitegroups/getbyid(" + GroupId + ")/users",
    type: "GET",
    async: false,
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data, status, xhr) {
      var dataresults = data.d.results;
      var assignedToPersonDetails =
        '<select id="assignedToPersonInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';
      for (var i = 0; i < dataresults.length; i++) {
        assignedToPersonDetails +=
          '<option value="' +
          dataresults[i].Title +
          '"selected>' +
          dataresults[i].Title +
          "</option>";
        //onsole.log("User Title - " + dataresults[i].Title);
      }
      assignedToPersonDetails += "</select>";
      $("#assignedToPersonInput").append(assignedToPersonDetails);

      if (ddlAssignedToPersonVal) {
        $(
          '#assignedToPersonInput option[value="' +
            ddlAssignedToPersonVal +
            '"]'
        ).prop("selected", true);
      } else {
        document.getElementById("assignedToPersonInputNew").selectedIndex = "0";
      }
    },
    error: function (xhr, status, error) {
      console.log("Failed");
    },
  });
}

function getAllUsersTeamFrom(assignedToGroupName) {
  var groupName = "Email ";
  groupName += assignedToGroupName;
  $.ajax({
    url:
      siteUrl +
      "/_api/web/sitegroups/?$filter=(Title eq '" +
      groupName +
      "')&$top=1",
    type: "GET",
    async: false,
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data, status, xhr) {
      getAllUsersTeamFromId(data.d.results[0].Id);
    },
    error: function (xhr, status, error) {
      console.log("Failed");
    },
  });
}

function getAllUsersTeamFromId(GroupId) {
  $("#divReallocateRequestToInputNew").remove();
  $.ajax({
    url: siteUrl + "/_api/web/sitegroups/getbyid(" + GroupId + ")/users",
    type: "GET",
    async: false,
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data, status, xhr) {
      var dataresults = data.d.results;
      var reAllocatePersonDetails =
        '<select id="divReallocateRequestToInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';
      for (var i = 0; i < dataresults.length; i++) {
        reAllocatePersonDetails +=
          '<option value="' +
          dataresults[i].Title +
          '"selected>' +
          dataresults[i].Title +
          "</option>";
        //onsole.log("User Title - " + dataresults[i].Title);
      }
      reAllocatePersonDetails += "</select>";
      $("#divReallocateRequestToInput").append(reAllocatePersonDetails);

      // if (ddlAssignedToPersonVal) {
      //   $(
      //     '#divAssignedToPersonInput option[value="' +
      //       ddlAssignedToPersonVal +
      //       '"]'
      //   ).prop("selected", true);
      // } else {
      document.getElementById("divReallocateRequestToInputNew").selectedIndex =
        "0";
      // }
    },
    error: function (xhr, status, error) {
      console.log("Failed");
    },
  });
}

function getAllUsersFromSiteGroupNew(assignedToGroupName) {
  var groupName = "Email ";
  groupName += assignedToGroupName;
  $.ajax({
    url:
      siteUrl +
      "/_api/web/sitegroups/?$filter=(Title eq '" +
      groupName +
      "')&$top=1",
    type: "GET",
    async: false,
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data, status, xhr) {
      getSiteUsersByGroupIdNew(data.d.results[0].Id);
    },
    error: function (xhr, status, error) {
      console.log("Failed");
    },
  });
}

function getSiteUsersByGroupIdNew(GroupId) {
  $("#divAssignedToPersonInputNew").remove();
  $.ajax({
    url: siteUrl + "/_api/web/sitegroups/getbyid(" + GroupId + ")/users",
    type: "GET",
    async: false,
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data, status, xhr) {
      var dataresults = data.d.results;
      var assignedToPersonDetails =
        '<select id="divAssignedToPersonInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';
      for (var i = 0; i < dataresults.length; i++) {
        assignedToPersonDetails +=
          '<option value="' +
          dataresults[i].Title +
          '"selected>' +
          dataresults[i].Title +
          "</option>";
        //onsole.log("User Title - " + dataresults[i].Title);
      }
      assignedToPersonDetails += "</select>";
      $("#divAssignedToPersonInput").append(assignedToPersonDetails);

      if (ddlAssignedToPersonVal) {
        $(
          '#divAssignedToPersonInput option[value="' +
            ddlAssignedToPersonVal +
            '"]'
        ).prop("selected", true);
      } else {
        document.getElementById("divAssignedToPersonInputNew").selectedIndex =
          "0";
      }
    },
    error: function (xhr, status, error) {
      console.log("Failed");
    },
  });
}

function getAttachments(itemId, Title, attachmentDivIDs) {
  // for(var i=0;i<attchmentFieldTitles.length;i++){
  //   $(attachmentDivID).empty();

  console.log("itemId: " + itemId);
  console.log("attachmentDivIDs: " + attachmentDivIDs);

  var attachmentDivID = "#";
  attachmentDivID += attachmentDivIDs;
  // attachmentDivID += "attachmentDivIDs";

  var restUrl =
    siteUrl +
    "/_api/web/lists/getbytitle('EmailManagementAttachments')/items?&$select=*&$expand=File&$filter=(ItemID eq '" +
    itemId +
    "' and Title eq '" +
    Title +
    "')";
  bindDataTable(restUrl, attachmentDivID);

  // }
}
function bindDataTable(restUrl, attachmentDivID) {
  // attachmentDivID = "#";
  // attachmentDivID+=attachmentDivID;
  console.log("attachmentDivID: " + attachmentDivID);

  $.ajax({
    url: restUrl,
    method: "GET",
    async: false,
    headers: {
      accept: "application/json;odata=verbose",
    },
    success: function (data) {
      if (data.d.results.length > 0) {
        // alert("bind Data table success attachmentDivID: "+attachmentDivID);
        $(attachmentDivID).append(generateTableFromJson(data.d.results));
      } else {
        $(attachmentDivID).append("<span>No attachment found.</span>");
      }
    },
    error: function (data) {
      $(attachmentDivID).append(
        "<span>Error while Retrieving Attachments. Error : " +
          JSON.stringify(data) +
          "</span>"
      );
    },
  });
}

function generateTableFromJson(objArray) {
  var onlyFileName;

  var tableContent = '<table class="baxstyles" style="border: 1px">';

  for (var i = 0; i < objArray.length; i++) {
    tableContent += '<tr style="border: 1px;">';

    tableContent +=
      '<td class="nr" style="display:none;">' + objArray[i].ID + "</td>";

    var itemID = objArray[i].ID;
    if (itemID == "undefined" || itemID == null || itemID == "") {
      itemID = "";
    }
    tableContent += '<td style="display:none;">' + itemID + "</td>";

    var stopCashId = objArray[i].ItemID;

    var attachmentName = "";
    var attachmentLink = "";

    if (
      objArray[i].FileAlreadyExists === "True" ||
      objArray[i].FileAlreadyExists === "true" ||
      objArray[i].FileAlreadyExists === true
    ) {
      var title = "";
      if (objArray[i].Title) {
        title = objArray[i].Title;
      }

      var removeText = "(" + title + stopCashId + ")";
      attachmentName = objArray[i].File.Name;
      attachmentLink = objArray[i].File.ServerRelativeUrl;
      attachmentLink = attachmentLink.replace(removeText, "");
    } else {
      attachmentName = objArray[i].File.Name;
      attachmentLink = objArray[i].File.ServerRelativeUrl;
    }

    onlyFileName = attachmentName.substr(0, attachmentName.lastIndexOf("."));
    if (
      attachmentName == "undefined" ||
      attachmentName == null ||
      attachmentName == ""
    ) {
      attachmentName = "";
    }
    tableContent +=
      '<td class="fileName" style="display:none;">' + onlyFileName + "</td>";

    // var attachmentLink = objArray[i].File.ServerRelativeUrl;
    var newHyperlink = attachmentLink;
    if (
      newHyperlink == "undefined" ||
      newHyperlink == null ||
      newHyperlink == ""
    ) {
      attachmentLink = "";
    }
    var fileLink = "https://conduent.sharepoint.com" + newHyperlink;
    tableContent += "<td>";
    tableContent += '<a  href="' + fileLink + '">' + onlyFileName + "</a>";
    tableContent += "</td>";

    var itemTitle = objArray[i].File.Title;
    if (itemTitle == "undefined" || itemTitle == null || itemTitle == "") {
      itemTitle = "";
    }
    tableContent += '<td style="display:none;">' + itemTitle + "</td>";
    if (statusRejectVal) {
      tableContent +=
        '<td align="center">' +
        "<input type='button' id='btnDelete' class='baxstyles' value='Delete'>" +
        "</td>";
    }

    tableContent += "</tr>";
  }

  return tableContent;
}

function addItemToList(
  regionInputVal,
  fromTeamInputVal,
  companyCodeInputVal,
  subjectInputVal,
  assignedToInputVal,
  subTeamInputVal,
  priorityInputVal,
  descriptionInputVal,
  customerNumberInputVal,
  customerNameInputVal
) {
  try {
    var loginuserid = _spPageContextInfo.userId;
    var queryUrl =
      siteUrl + "/_api/web/lists/getbytitle('Email Management')/items";
    $.ajax({
      url: queryUrl,
      type: "POST",
      async: false,
      contentType: "application/json;odata=verbose",
      data: JSON.stringify({
        __metadata: {
          type: "SP.Data.EmailManagementListItem",
        },
        Title: regionInputVal,
        FromTeam: fromTeamInputVal,
        FromCompanyCode: companyCodeInputVal,
        Subject: subjectInputVal,
        AssignedTo: assignedToInputVal,
        SubTeam: subTeamInputVal,
        Priority: priorityInputVal,
        CustomerNumber: customerNumberInputVal,
        CustomerName: customerNameInputVal,
        Description: descriptionInputVal,
        RequestCreatedGroup: currentUserGroupName,
        Status: "Not Started",
      }),
      headers: {
        accept: "application/json;odata=verbose",
        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
      },
      success: onQuerySuccess,
      error: onQueryFailure,
    });
  } catch (ex) {
    console.log("Exception" + ex.message);
    alert("Exception" + ex.message);
  }
}
function onQuerySuccess() {
  getLatestItemId();

  var url = siteUrl + "/SitePages/EmailManagement.aspx";

  var alertMessage = "Email Request created successfully";
  BootstrapDialog.show({
    title: "Information",
    message: alertMessage,
    animate: false,
    buttons: [
      {
        label: "Close",
        action: function (dialogRef) {
          dialogRef.close();
          $(location).attr("href", url);
        },
      },
    ],
  });
}
function getLatestItemId() {
  restUrl =
    siteUrl +
    "/_api/web/lists/getbytitle('Email Management')/items?&$select=ID&$orderby=ID desc&$top=1";
  return $.ajax({
    url: restUrl,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length;

      $.each(data.d.results, function (index, item) {
        let latestIDVal = item.ID;
        uploadFiles("emailAttachmentsNew", "Email Management New", latestIDVal);
      });
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}
function onQueryFailure(error) {
  alert(JSON.stringify(error));
}

function getRegionDetails() {
  $("#regionInputNew").remove();
  var bankURL =
    siteUrl +
    "/_api/web/lists/getbytitle('RegionDetails')/items?$select=ID,Title&$filter=(Status eq 'Active')&$orderby=ID asc&$top=1000";

  return $.ajax({
    url: bankURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length; //get items count
      var regionDetails =
        '<select id="regionInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';

      $.each(data.d.results, function (index, item) {
        regionDetails +=
          '<option value="' +
          item.Title +
          '"selected>' +
          item.Title +
          "</option>";
      });
      regionDetails += "</select>";
      $("#regionInput").append(regionDetails);

      if (ddlRegionVal) {
        $('#regionInput option[value="' + ddlRegionVal + '"]').prop(
          "selected",
          true
        );
      } else {
        document.getElementById("regionInputNew").selectedIndex = "0";
      }
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}

function getFromTeamDetails() {
  $("#fromTeamInputNew").remove();
  $("#assignedToInputNew").remove();
  var bankURL =
    siteUrl +
    "/_api/web/lists/getbytitle('FromTeamDetails')/items?$select=ID,Title&$filter=(Status eq 'Active')&$orderby=ID asc&$top=1000";

  return $.ajax({
    url: bankURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length; //get items count
      var fromTeamDetails =
        '<select id="fromTeamInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';
      var assignedToDetails =
        '<select id="assignedToInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';

      $.each(data.d.results, function (index, item) {
        fromTeamDetails +=
          '<option value="' +
          item.Title +
          '"selected>' +
          item.Title +
          "</option>";
        assignedToDetails +=
          '<option value="' +
          item.Title +
          '"selected>' +
          item.Title +
          "</option>";
      });

      fromTeamDetails += "</select>";
      assignedToDetails += "</select>";

      $("#fromTeamInput").append(fromTeamDetails);
      $("#assignedToInput").append(assignedToDetails);

      if (ddlFromTeamVal) {
        $('#fromTeamInput option[value="' + ddlFromTeamVal + '"]').prop(
          "selected",
          true
        );
      } else {
        document.getElementById("fromTeamInputNew").selectedIndex = "0";
      }

      if (ddlAssignedToVal) {
        $('#assignedToInput option[value="' + ddlAssignedToVal + '"]').prop(
          "selected",
          true
        );
      } else {
        document.getElementById("assignedToInputNew").selectedIndex = "0";
      }
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}

function getCompanyCodeDetails() {
  $("#companyCodeInputNew").remove();
  var bankURL =
    siteUrl +
    "/_api/web/lists/getbytitle('CompanyCodeDetails')/items?$select=ID,Title,SubTeam&$filter=(Status eq 'Active')&$orderby=ID asc&$top=1000";

  return $.ajax({
    url: bankURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length; //get items count
      var companyCodeDetails =
        '<select id="companyCodeInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';

      $.each(data.d.results, function (index, item) {
        if (item.Title && item.SubTeam) {
          companyCodeDetailsArray.push({
            companyCode: item.Title,
            subTeam: item.SubTeam,
          });
        }
        companyCodeDetails +=
          '<option value="' +
          item.Title +
          '"selected>' +
          item.Title +
          "</option>";
      });
      companyCodeDetails += "</select>";
      $("#companyCodeInput").append(companyCodeDetails);

      if (ddlCompanyCodeVal) {
        $('#companyCodeInput option[value="' + ddlCompanyCodeVal + '"]').prop(
          "selected",
          true
        );
      } else {
        document.getElementById("companyCodeInputNew").selectedIndex = "0";
      }
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}
function getCurrentUserName() {
  var userid = _spPageContextInfo.userId;

  var requestUri = siteUrl + "/_api/web/getuserbyid(" + userid + ")";
  var requestHeaders = { accept: "application/json;odata=verbose" };
  $.ajax({
    url: requestUri,
    contentType: "application/json;odata=verbose",
    headers: requestHeaders,
    async: false,
    success: onSuccess,
    error: onError,
  });
  function onSuccess(data, request) {
    var loginName = data.d.Title;
    currentUserName = data.d.Title;
  }
  function onError(error) {
    alert("Error on retrieving current user.");
  }
}

function getCurrentUserGroupName() {
  $.ajax({
    url: siteUrl + "/_api/web/CurrentUser",
    method: "GET",
    headers: { Accept: "application/json; odata=verbose" },
    success: function (data) {
      getCurrentUserGroupColl(data.d.Id);
    },
    error: function (data) {
      failure(data);
    },
  });
}
function getCurrentUserGroupColl(UserID) {
  $.ajax({
    url:
      _spPageContextInfo.webAbsoluteUrl +
      "/_api/web/GetUserById(" +
      UserID +
      ")/Groups",
    method: "GET",
    headers: { Accept: "application/json; odata=verbose" },
    success: function (data) {
      /* get all group's title of current user. */
      var results = data.d.results;
      var InnrHtmlgrp = "<ul>";
      for (var i = 0; i < results.length; i++) {
        currentUserGroupName = results[i].Title;
        if (currentUserGroupName.includes("Email")) {
          break;
        }
      }
    },
  });
}

function getCurrentUserGroupNameNew(groupName) {
  $.ajax({
    url: siteUrl + "/_api/web/CurrentUser",
    async: false,
    method: "GET",
    headers: { Accept: "application/json; odata=verbose" },
    success: function (data) {
      getCurrentUserGroupCollNew(data.d.Id, groupName);
    },
    error: function (data) {
      failure(data);
    },
  });
}
function getCurrentUserGroupCollNew(UserID, groupName) {
  $.ajax({
    url:
      _spPageContextInfo.webAbsoluteUrl +
      "/_api/web/GetUserById(" +
      UserID +
      ")/Groups",
    method: "GET",
    async: false,
    headers: { Accept: "application/json; odata=verbose" },
    success: function (data) {
      /* get all group's title of current user. */
      var results = data.d.results;
      var InnrHtmlgrp = "<ul>";
      for (var i = 0; i < results.length; i++) {
        var currentUserGroupName = results[i].Title;
        if (currentUserGroupName.includes("Email")) {
          if (groupName === currentUserGroupName) {
            isAssignedToGroupUser = true;
            break;
          } else {
            isAssignedToGroupUser = false;
          }
        }
      }
    },
  });
}

/* Attachment Code, Start*/

function uploadFiles(attachmentId, FieldTitleVal, latestIDVal) {
  // Define the folder path for this example.
  var serverRelativeUrlToFolder = "EmailManagementAttachments";

  // Get test values from the file input and text input page controls.
  var fileInput = jQuery("#" + attachmentId);

  // var newName = jQuery('#displayName').val();
  var fileCount = fileInput[0].files.length;
  // Get the server URL.
  var serverUrl = _spPageContextInfo.webAbsoluteUrl;
  var filesUploaded = 0;
  for (var i = 0; i < fileCount; i++) {
    // Initiate method calls using jQuery promises.
    // Get the local file as an array buffer.
    var getFile = getFileBuffer(i);
    getFile.done(function (arrayBuffer, i) {
      // Add the file to the SharePoint folder.
      var addFile = addFileToFolder(arrayBuffer, i);
      addFile.done(function (file, status, xhr) {
        //Get ID of File uploaded
        var getfileID = getItem(file.d);
        getfileID.done(
          function (fResult) {
            var colObject = new Object();
            colObject["Title"] = FieldTitleVal;
            colObject["ItemID"] = "" + latestIDVal + "";
            colObject["FileAlreadyExists"] = "" + fileAlreadyExists + "";
            var changeItem = updateFileMetadata(
              libraryName,
              fResult.d,
              colObject
            );
            changeItem.done(function (result) {
              filesUploaded++;
              if (fileCount == filesUploaded) {
                console.log("All files uploaded successfully");
                //$("#msg").append("<div>All files uploaded successfully</div>");
                $("#getFile").value = null;
                filesUploaded = 0;
              }
            });
            changeItem.fail(function (result) {});
          },
          function () {}
        );
      });
      addFile.fail(onError);
    });
    getFile.fail(onError);
  }
  function getItem(file) {
    var def = jQuery.Deferred();
    jQuery.ajax({
      url: file.ListItemAllFields.__deferred.uri,
      type: "GET",
      dataType: "json",
      headers: {
        Accept: "application/json;odata=verbose",
      },
      success: function (data) {
        def.resolve(data);
      },
      error: function (data, arg, jhr) {
        def.reject(data, arg, jhr);
      },
    });
    return def.promise();
    //return call;
  }

  // Get the local file as an array buffer.
  function getFileBuffer(i) {
    var deferred = jQuery.Deferred();
    var reader = new FileReader();
    reader.onloadend = function (e) {
      deferred.resolve(e.target.result, i);
    };
    reader.onerror = function (e) {
      deferred.reject(e.target.error);
    };
    reader.readAsArrayBuffer(fileInput[0].files[i]);
    return deferred.promise();
  }

  // Add the file to the file collection in the Shared Documents folder.
  function addFileToFolder(arrayBuffer, i) {
    var index = i;

    fileAlreadyExists = false;

    // Get the file name from the file input control on the page.
    var fileName = fileInput[0].files[index].name;

    var isFileExists = checkIfFileAlreadyExists(fileName);

    if (isFileExists === true) {
      fileName = fileName + "(" + FieldTitleVal + latestIDVal + ")";
      fileAlreadyExists = true;
    }

    console.log("fileName: " + fileName);

    // Construct the endpoint.
    var fileCollectionEndpoint = String.format(
      "{0}/_api/web/getfolderbyserverrelativeurl('{1}')/files" +
        "/add(overwrite=true, url='{2}')",
      siteUrl,
      serverRelativeUrlToFolder,
      fileName
    );

    // Send the request and return the response.
    // This call returns the SharePoint file.
    return jQuery.ajax({
      url: fileCollectionEndpoint,
      type: "POST",
      data: arrayBuffer,
      processData: false,
      headers: {
        accept: "application/json;odata=verbose",
        "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
        "content-length": arrayBuffer.byteLength,
      },
    });
  }
}

// Display error messages.
function onError(error) {
  alert(error.responseText);
}

function updateFileMetadata(libraryName, item, colPropObject) {
  var def = jQuery.Deferred();

  var restSource =
    siteUrl +
    "/_api/Web/Lists/getByTitle('" +
    libraryName +
    "')/Items(" +
    item.Id +
    ")";
  var jsonString = "";

  var metadataColumn = new Object();
  metadataColumn["type"] = item.__metadata.type;
  //columnArray.push(metadataColumn);
  if (colPropObject == null || colPropObject == "undefined") {
    // For library having no column properties to be updated
    colPropObject = new Object();
  }
  colPropObject["__metadata"] = metadataColumn;
  jsonString = JSON.stringify(colPropObject);
  var dfd = jQuery.Deferred();
  jQuery.ajax({
    url: restSource,
    method: "POST",
    data: jsonString,
    headers: {
      accept: "application/json;odata=verbose",
      "content-type": "application/json;odata=verbose",
      "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
      "IF-MATCH": item.__metadata.etag,
      "X-Http-Method": "MERGE",
    },
    success: function (data) {
      var d = data;
      dfd.resolve(d);
    },
    error: function (err) {
      dfd.reject(err);
    },
  });

  return dfd.promise();
}

function checkIfFileAlreadyExists(fileName) {
  let isFileExists = false;
  let filePath = "/teams/GM-ARIEN/EmailManagementAttachments/" + fileName;
  jQuery.ajax({
    url:
      _spPageContextInfo.webAbsoluteUrl +
      "/_api/web/getfilebyserverrelativeurl('" +
      filePath +
      "')",
    type: "GET",
    async: false,
    headers: {
      accept: "application/json;odata=verbose",
    },
    success: function (data) {
      isFileExists = true;
      console.log("file exists");
    },
    error: function (error) {
      if (error.status == 404) {
        console.log("file doesnt exist");
      }
    },
  });
  return isFileExists;
}
/* Attachment Code, End*/

$("table").delegate("#btnDelete", "click", function (e) {
  var $row = $(this).closest("tr");
  var ItemID = $row.find(".nr").text();
  var textFileName = $row.find(".fileName").text();
  deleteAttachment(ItemID, textFileName);
  e.preventDefault();
});

function deleteAttachment(text, onlyFileName) {
  var deleteURL =
    siteUrl +
    "/_api/web/lists/GetByTitle('EmailManagementAttachments')/items('" +
    text +
    "')";
  $.ajax({
    url: deleteURL,
    type: "POST",
    async: false,
    headers: {
      Accept: "application/json;odata=verbose",
      "X-RequestDigest": $("#__REQUESTDIGEST").val(),
      "IF-MATCH": "*",
      "X-HTTP-Method": "DELETE",
    },
    success: function (data, status, xhr) {
      alert("File - (" + onlyFileName + ") has been deleted successfully");
      window.location.reload();
    },
    error: function (xhr, status, error) {
      alert("Delete Function Failed");
      //$("#ResultDiv").empty().text(data.responseJSON.error);
    },
  });
}
