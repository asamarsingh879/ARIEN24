var siteUrl = _spPageContextInfo.webServerRelativeUrl;
var listName = "Email Management";
var libraryName = "EmailManagementAttachments";
var groupName = "Service Desk";
var companyCodeDetailsArray = [];
var ddlRegionVal = "";
var ddlFromTeamVal = "";
var ddlAssignedToVal = "";
var ddlCompanyCodeVal = "";
let fileAlreadyExists = false;
let currentUserGroupName = "";
let currentUserName = "";
let requestSubmittedDateTime = "";

$(document).ready(function () {
  $("#divResponse").hide();
  getRegionDetails();
  getCurrentUserGroupName();

  getCompanyCodeDetails();

  getCurrentUserName();

  $("#companyCodeInput").change(function () {
    var companyCodeVal = $("#companyCodeInput option:selected").text();
    if (companyCodeVal == "Select") {
      $("#subTeamInput").val("");
    } else {
      console.log(
        "companyCodeDetailsArray(): " + JSON.stringify(companyCodeDetailsArray)
      );
      if (companyCodeDetailsArray.length > 0) {
        for (var i = 0; i < companyCodeDetailsArray.length; i++) {
          if (companyCodeDetailsArray[i].companyCode === companyCodeVal) {
            $("#subTeamInput").val(companyCodeDetailsArray[i].subTeam);
          }
        }
      }
    }
  });

  $("#btnSubmit").click(function () {
    requestSubmittedDateTime = getDateTime();
    var regionInputVal = $("#regionInput option:selected").text();
    if (regionInputVal !== "Select") {
    } else {
      regionInputVal = "";
    }

    var fromTeamInputVal = $("#fromTeamInput option:selected").text();
    if (fromTeamInputVal !== "Select") {
    } else {
      fromTeamInputVal = "";
    }

    var companyCodeInputVal = $("#companyCodeInput option:selected").text();
    if (companyCodeInputVal !== "Select") {
    } else {
      companyCodeInputVal = "";
    }
    var subjectInputVal = $("#subjectInput").val();
    var assignedToInputVal = $("#assignedToInput option:selected").text();
    if (assignedToInputVal !== "Select") {
    } else {
      assignedToInputVal = "";
    }

    var subTeamInputVal = $("#subTeamInput").val();

    var priorityInputVal = $("#priorityInput option:selected").text();
    if (priorityInputVal !== "Select") {
    } else {
      priorityInputVal = "";
    }

    var customerNumberInputVal = $("#customerNumberInput").val();
    var customerNameInputVal = $("#customerNameInput").val();

    var descriptionInputVal = $("#descriptionInput").val();

    var approvalDetails = [];

    var approvalSectionDetails = "";

    approvalSectionDetails = {
      hierarchy1: "Requested By",
      name: currentUserName,
      date: requestSubmittedDateTime,
      hierarchy2: "Request Assigned To - " + assignedToInputVal,
      status: "Not Started",
      comments: descriptionInputVal,
    };

    approvalDetails.push(approvalSectionDetails);

    if (
      regionInputVal &&
      fromTeamInputVal &&
      companyCodeInputVal &&
      subjectInputVal &&
      assignedToInputVal &&
      subTeamInputVal &&
      priorityInputVal &&
      descriptionInputVal
    ) {
      addItemToList(
        regionInputVal,
        fromTeamInputVal,
        companyCodeInputVal,
        subjectInputVal,
        assignedToInputVal,
        subTeamInputVal,
        priorityInputVal,
        descriptionInputVal,
        customerNumberInputVal,
        customerNameInputVal,
        approvalDetails
      );
    } else {
      var alertMessage =
        "Request form is incomplete. Please fill all mandatory columns!";
      BootstrapDialog.show({
        title: "Information",
        message: alertMessage,
        animate: false,
        buttons: [
          {
            label: "Close",
            action: function (dialogRef) {
              dialogRef.close();
            },
          },
        ],
      });

      //alert("Stop Cash Request form is incomplete. Please fill all mandatory columns!");
    }
  });

  $("#btnCancel").click(function () {
    var url = siteUrl + "/SitePages/ARIENDashboard.aspx";
    var alertMessage = "Are you sure that you want to close this form";

    BootstrapDialog.show({
      message: alertMessage,
      animate: false,
      buttons: [
        {
          label: "Yes",
          action: function (dialogRef) {
            dialogRef.close();

            $(location).attr("href", url);
          },
        },
      ],
    });
  });
});

function getCurrentUserName() {
  var userid = _spPageContextInfo.userId;
  // alert(userid);

  var requestUri = siteUrl + "/_api/web/getuserbyid(" + userid + ")";
  var requestHeaders = { accept: "application/json;odata=verbose" };
  $.ajax({
    url: requestUri,
    async: false,
    contentType: "application/json;odata=verbose",
    headers: requestHeaders,
    success: onSuccess,
    error: onError,
  });
  function onSuccess(data, request) {
    var loginName = data.d.Title;
    currentUserName = data.d.Title;
  }
  function onError(error) {
    alert("Error on retrieving current user.");
  }
}

function getDateTime() {
  var now = new Date();
  // now = now.toDateString();
  // now = now.toLocaleTimeString();

  console.log("now: " + now);
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var day = now.getDate();
  var hour = now.getHours();
  var minute = now.getMinutes();
  var second = now.getSeconds().toFixed(2);

  if (month.toString().length == 1) {
    month = "0" + month;
  }
  if (day.toString().length == 1) {
    day = "0" + day;
  }
  if (hour.toString().length == 1) {
    hour = "0" + hour;
  }
  if (minute.toString().length == 1) {
    minute = "0" + minute;
  }
  if (second.toString().length == 1) {
    second = "0" + second;
  }
  var dateTime = month + "/" + day + "/" + year + " " + hour + ":" + minute;
  // console.log(dateTime);
  // alert("cashApplicationDate: " + dateTime)
  //requestSubmittedDateTime = dateTime;
  return dateTime;
}

function addItemToList(
  regionInputVal,
  fromTeamInputVal,
  companyCodeInputVal,
  subjectInputVal,
  assignedToInputVal,
  subTeamInputVal,
  priorityInputVal,
  descriptionInputVal,
  customerNumberInputVal,
  customerNameInputVal,
  approvalDetails
) {
  try {
    var loginuserid = _spPageContextInfo.userId;
    // var currentUserGroupNameVal = currentUserGroupName;
    // currentUserGroupNameVal = currentUserGroupNameVal.substring(6);

    var queryUrl =
      siteUrl + "/_api/web/lists/getbytitle('Email Management')/items";
    $.ajax({
      url: queryUrl,
      type: "POST",
      async: false,
      contentType: "application/json;odata=verbose",
      data: JSON.stringify({
        __metadata: {
          type: "SP.Data.EmailManagementListItem",
        },
        Title: regionInputVal,
        FromTeam: fromTeamInputVal,
        FromCompanyCode: companyCodeInputVal,
        Subject: subjectInputVal,
        AssignedTo: assignedToInputVal,
        SubTeam: subTeamInputVal,
        Priority: priorityInputVal,
        CustomerNumber: customerNumberInputVal,
        CustomerName: customerNameInputVal,
        Description: descriptionInputVal,
        RequestCreatedGroup: fromTeamInputVal,
        Status: "Not Started",
        ApprovalDetails: JSON.stringify(approvalDetails),
      }),
      headers: {
        accept: "application/json;odata=verbose",
        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
      },
      success: onQuerySuccess,
      error: onQueryFailure,
    });
  } catch (ex) {
    console.log("Exception" + ex.message);
    alert("Exception" + ex.message);
  }
}
function onQuerySuccess() {
  getLatestItemId();

  var url = siteUrl + "/SitePages/ARIENNew.aspx";

  var alertMessage = "Request created successfully";
  BootstrapDialog.show({
    title: "Information",
    message: alertMessage,
    animate: false,
    buttons: [
      {
        label: "Close",
        action: function (dialogRef) {
          dialogRef.close();
          $(location).attr("href", url);
        },
      },
    ],
  });

  // $("#rightNowTicketNoInput").val("");
  // $('#requestTypeInput option:selected').text();
  // $("#vendorNoInput").val("");
  // $("#vendorNameInput").val("");
  // $("#companyCodeInput").val("");
  // $("#chequeNoInput").val("");
  // $("#chequeDateInput").val("");
  // $("#chequeAmountInput").val("");
  // $("#currencyInput").val("");
  // // $("#bankAccountInput").val("");
  // $('#bankAccountInput option:selected').text();
  // $("#bankAccountNameInput").val("");
  // $("#requestReasonInput").val("");
  // $('#priorityInput option:selected').text();
}
function getLatestItemId() {
  restUrl =
    siteUrl +
    "/_api/web/lists/getbytitle('Email Management')/items?&$select=ID&$orderby=ID desc&$top=1";
  return $.ajax({
    url: restUrl,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length;

      $.each(data.d.results, function (index, item) {
        let latestIDVal = item.ID;
        uploadFiles("emailAttachmentsNew", "Email Management New", latestIDVal);
      });
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}
function onQueryFailure(error) {
  alert(JSON.stringify(error));
}

function getRegionDetails() {
  $("#regionInputNew").remove();
  var bankURL =
    siteUrl +
    "/_api/web/lists/getbytitle('RegionDetails')/items?$select=ID,Title&$filter=(Status eq 'Active')&$orderby=ID asc&$top=1000";

  return $.ajax({
    url: bankURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length; //get items count
      var regionDetails =
        '<select id="regionInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';

      $.each(data.d.results, function (index, item) {
        regionDetails +=
          '<option value="' +
          item.Title +
          '"selected>' +
          item.Title +
          "</option>";
      });
      regionDetails += "</select>";
      $("#regionInput").append(regionDetails);

      if (ddlRegionVal) {
        $('#regionInput option[value="' + ddlRegionVal + '"]').prop(
          "selected",
          true
        );
      } else {
        document.getElementById("regionInputNew").selectedIndex = "0";
      }
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}

function getFromTeamDetails() {
  $("#fromTeamInputNew").remove();
  $("#assignedToInputNew").remove();
  var bankURL =
    siteUrl +
    "/_api/web/lists/getbytitle('FromTeamDetails')/items?$select=ID,Title&$filter=(Status eq 'Active')&$orderby=ID asc&$top=1000";

  return $.ajax({
    url: bankURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length; //get items count
      var fromTeamDetails =
        '<select id="fromTeamInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';
      var assignedToDetails =
        '<select id="assignedToInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';

      $.each(data.d.results, function (index, item) {
        fromTeamDetails +=
          '<option value="' +
          item.Title +
          '"selected>' +
          item.Title +
          "</option>";
        assignedToDetails +=
          '<option value="' +
          item.Title +
          '"selected>' +
          item.Title +
          "</option>";
      });

      fromTeamDetails += "</select>";
      assignedToDetails += "</select>";

      $("#fromTeamInput").append(fromTeamDetails);
      $("#assignedToInput").append(assignedToDetails);

      var currentUserGroupNameVal = currentUserGroupName;
      currentUserGroupNameVal = currentUserGroupNameVal.substring(6);
      // if (currentUserGroupNameVal) {
      //   $(
      //     '#fromTeamInput option[value="' + currentUserGroupNameVal + '"]'
      //   ).prop("selected", true);
      // }

      document.getElementById("fromTeamInputNew").selectedIndex = "0";

      document.getElementById("assignedToInputNew").selectedIndex = "0";

      // $("#fromTeamInputNew").prop("disabled", true);
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}

function getCompanyCodeDetails() {
  $("#companyCodeInputNew").remove();
  var bankURL =
    siteUrl +
    "/_api/web/lists/getbytitle('CompanyCodeDetails')/items?$select=ID,Title,SubTeam&$filter=(Status eq 'Active')&$orderby=ID asc&$top=1000";

  return $.ajax({
    url: bankURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length; //get items count
      var companyCodeDetails =
        '<select id="companyCodeInputNew" class="form-control" class="col-xs-4"> <option value="">Select</option>';

      $.each(data.d.results, function (index, item) {
        if (item.Title && item.SubTeam) {
          companyCodeDetailsArray.push({
            companyCode: item.Title,
            subTeam: item.SubTeam,
          });
        }
        companyCodeDetails +=
          '<option value="' +
          item.Title +
          '"selected>' +
          item.Title +
          "</option>";
      });
      companyCodeDetails += "</select>";
      $("#companyCodeInput").append(companyCodeDetails);

      if (ddlCompanyCodeVal) {
        $('#companyCodeInput option[value="' + ddlCompanyCodeVal + '"]').prop(
          "selected",
          true
        );
      } else {
        document.getElementById("companyCodeInputNew").selectedIndex = "0";
      }
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}

function getCurrentUserGroupName() {
  $.ajax({
    url: siteUrl + "/_api/web/CurrentUser",
    method: "GET",
    async: false,
    headers: { Accept: "application/json; odata=verbose" },
    success: function (data) {
      getCurrentUserGroupColl(data.d.Id);
    },
    error: function (data) {
      failure(data);
    },
  });
}
function getCurrentUserGroupColl(UserID) {
  $.ajax({
    url:
      _spPageContextInfo.webAbsoluteUrl +
      "/_api/web/GetUserById(" +
      UserID +
      ")/Groups",
    method: "GET",
    headers: { Accept: "application/json; odata=verbose" },
    success: function (data) {
      /* get all group's title of current user. */
      var results = data.d.results;
      var InnrHtmlgrp = "<ul>";
      for (var i = 0; i < results.length; i++) {
        currentUserGroupName = results[i].Title;
        if (currentUserGroupName.includes("Email")) {
          if (currentUserGroupName !== "Email Admins") {
            // alert("currentUserGroupName: " + currentUserGroupName);
            break;
          }
        }
      }
      getFromTeamDetails();
    },
  });
}

/* Attachment Code, Start*/

function uploadFiles(attachmentId, FieldTitleVal, latestIDVal) {
  // Define the folder path for this example.
  var serverRelativeUrlToFolder = "EmailManagementAttachments";

  // Get test values from the file input and text input page controls.
  var fileInput = jQuery("#" + attachmentId);

  // var newName = jQuery('#displayName').val();
  var fileCount = fileInput[0].files.length;
  // Get the server URL.
  var serverUrl = _spPageContextInfo.webAbsoluteUrl;
  var filesUploaded = 0;
  for (var i = 0; i < fileCount; i++) {
    // Initiate method calls using jQuery promises.
    // Get the local file as an array buffer.
    var getFile = getFileBuffer(i);
    getFile.done(function (arrayBuffer, i) {
      // Add the file to the SharePoint folder.
      var addFile = addFileToFolder(arrayBuffer, i);
      addFile.done(function (file, status, xhr) {
        //Get ID of File uploaded
        var getfileID = getItem(file.d);
        getfileID.done(
          function (fResult) {
            var colObject = new Object();
            colObject["Title"] = FieldTitleVal;
            colObject["ItemID"] = "" + latestIDVal + "";
            colObject["FileAlreadyExists"] = "" + fileAlreadyExists + "";
            var changeItem = updateFileMetadata(
              libraryName,
              fResult.d,
              colObject
            );
            changeItem.done(function (result) {
              filesUploaded++;
              if (fileCount == filesUploaded) {
                console.log("All files uploaded successfully");
                //$("#msg").append("<div>All files uploaded successfully</div>");
                $("#getFile").value = null;
                filesUploaded = 0;
              }
            });
            changeItem.fail(function (result) {});
          },
          function () {}
        );
      });
      addFile.fail(onError);
    });
    getFile.fail(onError);
  }
  function getItem(file) {
    var def = jQuery.Deferred();
    jQuery.ajax({
      url: file.ListItemAllFields.__deferred.uri,
      type: "GET",
      async: false,
      dataType: "json",
      headers: {
        Accept: "application/json;odata=verbose",
      },
      success: function (data) {
        def.resolve(data);
      },
      error: function (data, arg, jhr) {
        def.reject(data, arg, jhr);
      },
    });
    return def.promise();
    //return call;
  }

  // Get the local file as an array buffer.
  function getFileBuffer(i) {
    var deferred = jQuery.Deferred();
    var reader = new FileReader();
    reader.onloadend = function (e) {
      deferred.resolve(e.target.result, i);
    };
    reader.onerror = function (e) {
      deferred.reject(e.target.error);
    };
    reader.readAsArrayBuffer(fileInput[0].files[i]);
    return deferred.promise();
  }

  // Add the file to the file collection in the Shared Documents folder.
  function addFileToFolder(arrayBuffer, i) {
    var index = i;

    fileAlreadyExists = false;

    // Get the file name from the file input control on the page.
    var fileName = fileInput[0].files[index].name;

    var isFileExists = checkIfFileAlreadyExists(fileName);

    if (isFileExists === true) {
      fileName = fileName + "(" + FieldTitleVal + latestIDVal + ")";
      fileAlreadyExists = true;
    }

    console.log("fileName: " + fileName);

    // Construct the endpoint.
    var fileCollectionEndpoint = String.format(
      "{0}/_api/web/getfolderbyserverrelativeurl('{1}')/files" +
        "/add(overwrite=true, url='{2}')",
      siteUrl,
      serverRelativeUrlToFolder,
      fileName
    );

    // Send the request and return the response.
    // This call returns the SharePoint file.
    return jQuery.ajax({
      url: fileCollectionEndpoint,
      type: "POST",
      async: false,
      data: arrayBuffer,
      processData: false,
      headers: {
        accept: "application/json;odata=verbose",
        "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
        "content-length": arrayBuffer.byteLength,
      },
    });
  }
}

// Display error messages.
function onError(error) {
  alert(error.responseText);
}

function updateFileMetadata(libraryName, item, colPropObject) {
  var def = jQuery.Deferred();

  var restSource =
    siteUrl +
    "/_api/Web/Lists/getByTitle('" +
    libraryName +
    "')/Items(" +
    item.Id +
    ")";
  var jsonString = "";

  var metadataColumn = new Object();
  metadataColumn["type"] = item.__metadata.type;
  //columnArray.push(metadataColumn);
  if (colPropObject == null || colPropObject == "undefined") {
    // For library having no column properties to be updated
    colPropObject = new Object();
  }
  colPropObject["__metadata"] = metadataColumn;
  jsonString = JSON.stringify(colPropObject);
  var dfd = jQuery.Deferred();
  jQuery.ajax({
    url: restSource,
    method: "POST",
    data: jsonString,
    headers: {
      accept: "application/json;odata=verbose",
      "content-type": "application/json;odata=verbose",
      "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
      "IF-MATCH": item.__metadata.etag,
      "X-Http-Method": "MERGE",
    },
    success: function (data) {
      var d = data;
      dfd.resolve(d);
    },
    error: function (err) {
      dfd.reject(err);
    },
  });

  return dfd.promise();
}

function checkIfFileAlreadyExists(fileName) {
  let isFileExists = false;
  let filePath = "/teams/GM-ARIEN/EmailManagementAttachments/" + fileName;
  jQuery.ajax({
    url:
      _spPageContextInfo.webAbsoluteUrl +
      "/_api/web/getfilebyserverrelativeurl('" +
      filePath +
      "')",
    type: "GET",
    async: false,
    headers: {
      accept: "application/json;odata=verbose",
    },
    success: function (data) {
      isFileExists = true;
      console.log("file exists");
    },
    error: function (error) {
      if (error.status == 404) {
        console.log("file doesnt exist");
      }
    },
  });
  return isFileExists;
}
/* Attachment Code, End*/
