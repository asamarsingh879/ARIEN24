var siteUrl = _spPageContextInfo.webServerRelativeUrl;
var isARIENAdmin = false;
var isARIENSupervisor = false;
$(document).ready(function () {
  ExecuteOrDelayUntilScriptLoaded(bindSubTeam, "sp.js");

  isARIENAdmin = isMemberOfGroup("Email Admins");
  isARIENSupervisor = isMemberOfGroup("Email Managers-or-Supervisors");

  var restURL =
    siteUrl +
    "/_api/web/lists/getbytitle('Email Management')/items?$select=ID,Title,FromTeam,FromCompanyCode,Subject,AssignedTo,SubTeam,Priority,CustomerNumber,CustomerName,Description,Status,Created,Author/Title,RequestCreatedGroup,AssignedToPerson,RequestClosedBy,RequestClosedDate&$expand=Author/Title&$orderby=ID asc&$top=5000";
  getEmailManagementDetails(restURL);

  $("#ddlSubTeam").change(function () {
    var ddlSelectedValue = $("#ddlSubTeam option:selected").text();
    if (ddlSelectedValue != "All") {
      var restURL =
        siteUrl +
        "/_api/web/lists/getbytitle('Email Management')/items?$select=ID,Title,FromTeam,FromCompanyCode,Subject,AssignedTo,SubTeam,Priority,CustomerNumber,CustomerName,Description,Status,Created,Author/Title,RequestCreatedGroup,AssignedToPerson,RequestClosedBy,RequestClosedDate&$expand=Author/Title&$filter=(SubTeam eq '" +
        ddlSelectedValue +
        "')&$orderby=ID asc&$top=5000";
      getEmailManagementDetails(restURL);
    } else {
      var restURL =
        siteUrl +
        "/_api/web/lists/getbytitle('Email Management')/items?$select=ID,Title,FromTeam,FromCompanyCode,Subject,AssignedTo,SubTeam,Priority,CustomerNumber,CustomerName,Description,Status,Created,Author/Title,RequestCreatedGroup,AssignedToPerson,RequestClosedBy,RequestClosedDate&$expand=Author/Title&$orderby=ID asc&$top=5000";
      getEmailManagementDetails(restURL);
    }
  });

  $("#ARIENDataTable").DataTable({
    dom: '<"dt-buttons"Bf><"clear">lirtp',
    paging: true,
    autoWidth: true,
    columnDefs: [{ orderable: false, targets: 5 }],
    buttons: [
      "colvis",
      {
        extend: "excelHtml5",
        text: "Export to Excel",
        title: "ARIEN Requests",
        exportOptions: {
          columns: ":visible",
        },
      },
    ],
    pageLength: 10,
    lengthMenu: [0, 5, 10, 20, 50, 100, 200, 500],
    order: [[1, "desc"]],
  });

  $("#ARIENDataTable tfoot th").each(function () {
    var title = $(this).text();
    $(this).html('<input type="text" placeholder=" ' + title + ' " />');
  });

  // DataTable
  var rtable = $("#ARIENDataTable").DataTable();

  // Apply the search
  rtable.columns().every(function () {
    var that = this;
    $("input", this.footer()).on("keyup change", function () {
      if (that.search() !== this.value) {
        that.search(this.value).draw();
      }
    });
  });

  $("table").delegate("#btnUpdate", "click", function (e) {
    var $row = $(this).closest("tr");
    var $ItemID = $row.find(".nr").text();

    var newTab = window.open(
      siteUrl + "/SitePages/ARIENEdit.aspx?k=" + $ItemID,
      "_blank"
    );
    if (newTab) {
      newTab.focus();
    }
    //else{
    // 	alert('Please allow popups for this website');
    // }
    // window.location.replace(siteUrl + '/SitePages/EmailManagementEdit.aspx?k='+$ItemID);
    e.preventDefault();
  });

  $("table").delegate("#btnDelete", "click", function (e) {
    var $row = $(this).closest("tr");
    var $ItemID = $row.find(".nr").text();

    var isConfirm = confirm(
      "Are you sure, you want to delete request # '" + $ItemID + "'?"
    );
    if (isConfirm) {
      deleteARIENRequest($ItemID);
      e.preventDefault();
    } else {
      return false;
    }
  });

  $("table").delegate("#btnUpdate", "click", function (e) {
    var $row = $(this).closest("tr");
    var $ItemID = $row.find(".nr").text();
    var projectNo = $("#ddlProjectNo option:selected").text();
    if (projectNo === "Select Any Project") {
    } else {
      window.location.replace(
        url +
          "/SitePages/AuditObservationEditForm.aspx?k=" +
          $ItemID +
          "auditNumTitle" +
          projectNo
      );
      e.preventDefault();
    }
  });

  $("#myModal").on("hidden.bs.modal", function (evt) {
    $(".modal .modal-body").empty();
  });
});

function bindSubTeam() {
  var restURL =
    siteUrl +
    "/_api/web/lists/getbytitle('Email Management')/items?&$select=ID,SubTeam&$top=5000";
  $.ajax({
    url: restURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      subTeamValues = [];
      subTeamUniqueDetails = [];
      items = data.d.results.length; //get items count
      var inputSubTeam =
        '<select id="ddlSubTeamNew" class="col-xs-4 form-control"> <option value="">All</option>';

      $.each(data.d.results, function (index, item) {
        var subTeamVal = item.SubTeam;
        if (subTeamVal != null && subTeamVal != undefined) {
          subTeamValues.push(subTeamVal);
        }
      });

      if (subTeamValues.length > 0) {
        $.each(subTeamValues, function (i, el) {
          if ($.inArray(el, subTeamUniqueDetails) === -1)
            subTeamUniqueDetails.push(el);
        });
        for (var e = 0; e < subTeamUniqueDetails.length; e++) {
          inputSubTeam +=
            '<option value="' +
            subTeamUniqueDetails[e] +
            '"selected>' +
            subTeamUniqueDetails[e] +
            "</option>";
        }
      }
      inputSubTeam += "</select>";
      $("#ddlSubTeam").append(inputSubTeam);

      $("#ddlSubTeamNew").each(function () {
        $("option", this).each(function () {
          if ($(this).text() == "All") {
            $(this).attr("selected", "selected");
          }
        });
      });
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });
}

function fnAddNewRequest() {
  var url = siteUrl + "/SitePages/ARIENNew.aspx";
  window.open(url, "_blank");
}

function deleteARIENRequest(itemID) {
  var deleteURL =
    siteUrl +
    "/_api/web/lists/GetByTitle('Email Management')/items('" +
    itemID +
    "')";
  $.ajax({
    url: deleteURL,
    type: "POST",
    async: false,
    headers: {
      Accept: "application/json;odata=verbose",
      "X-RequestDigest": $("#__REQUESTDIGEST").val(),
      "IF-MATCH": "*",
      "X-HTTP-Method": "DELETE",
    },
    success: function (data, status, xhr) {
      location.reload();
    },
    error: function (xhr, status, error) {},
  });
}

function getEmailManagementDetails(restURL) {
  var tableContent =
    "<thead><tr><th style='text-align:center;'>Actions</th><th>Request #</th><th>Status</th><th>Pending with?</th><th>Req Created on</th><th>Req Created by</th><th>Req Created Group</th><th>Priority</th><th>No Of Days</th><th>Region</th><th>From Team</th><th>Sub Team</th><th>Comp Code</th><th>Subject</th><th>Assigned To Team</th><th>Assigned To Person</th><th>Req Closed by</th><th>Req Closed on</th></tr></thead><tfoot><tr><th style='text-align:center;'>Actions</th><th>Request #</th><th>Status</th><th>Pending with?</th><th>Req Created on</th><th>Req Created by</th><th>Req Created Group</th><th>Priority</th><th>No Of Days</th><th>Region</th><th>From Team</th><th>Sub Team</th><th>Comp Code</th><th>Subject</th><th>Assigned To Team</th><th>Assigned To Person</th><th>Req Closed by</th><th>Req Closed on</th></tr></tfoot>"; // add resources

  $.ajax({
    url: restURL,
    type: "GET",
    async: false,
    contentType: "application/json;odata=verbose",
    headers: {
      Accept: "application/json;odata=verbose",
    },
    success: function (data) {
      items = data.d.results.length; //get items count

      $.each(data.d.results, function (index, item) {
        tableContent += "<tr>";
        if (isARIENAdmin === true || isARIENSupervisor === true) {
          tableContent +=
            '<td style="text-align:center;">' +
            "<button type='button' id='btnUpdate' class='btn btn-primary btn-xs dt-edit' style='margin-right:16px;'>" +
            "<span class='glyphicon glyphicon-pencil' aria-hidden='true'></span>" +
            "</button>";

          tableContent +=
            "<button type='button' id='btnDelete' class='btn btn-danger btn-xs dt-delete'>" +
            "<span class='glyphicon glyphicon-remove' aria-hidden='true'></span>" +
            "</button>" +
            "</td>";
        } else {
          tableContent +=
            '<td style="text-align:center;">' +
            "<button type='button' id='btnUpdate' class='btn btn-primary btn-xs dt-edit text-center' style='margin-right:16px;'>" +
            "<span class='glyphicon glyphicon-pencil' aria-hidden='true'></span>" +
            "</button>" +
            "</td>";
        }

        tableContent += '<td class="nr">' + item.ID + "</td>";
        var status = item.Status;
        if (status == "undefined" || status == null || status == "") {
          status = "";
        }
        tableContent += '<td align="left">' + status + "</td>";

        var pendindWith = "";
        var requestCreatedBy = item.Author.Title;
        if (item.Status == "Not Started") {
          pendindWith = item.AssignedTo;
        } else if (item.Status == "In Progress") {
          pendindWith = item.AssignedToPerson;
        } else if (
          item.Status == "Response Received" ||
          item.Status == "Rejected"
        ) {
          pendindWith = requestCreatedBy;
        }
        tableContent += '<td align="left">' + pendindWith + "</td>";

        var requestCreatedDate = "";
        if (item.Created) {
          requestCreatedDate = getDateTime(item.Created);
        }
        tableContent += '<td align="left">' + requestCreatedDate + "</td>";

        if (
          requestCreatedBy == "undefined" ||
          requestCreatedBy == null ||
          requestCreatedBy == ""
        ) {
          requestCreatedBy = "";
        }
        tableContent += '<td align="left">' + requestCreatedBy + "</td>";

        var requestCreatedGroup = item.RequestCreatedGroup;
        if (
          requestCreatedGroup == "undefined" ||
          requestCreatedGroup == null ||
          requestCreatedGroup == ""
        ) {
          requestCreatedGroup = "";
        }
        tableContent += '<td align="left">' + requestCreatedGroup + "</td>";

        var priority = item.Priority;
        if (priority == "undefined" || priority == null || priority == "") {
          priority = "";
        }
        if (priority == "Urgent") {
          tableContent +=
            '<td align="left" class="urgent">' + priority + "</td>";
        } else {
          tableContent += '<td align="left">' + priority + "</td>";
        }
        // tableContent += '<td align="left">' + priority + '</td>';

        var noOfDays = 0;
        if (item.Status !== "Completed") {
          var createdDate = getFormattedDate(item.Created);
          noOfDays = getCalculatedDays(createdDate);
          tableContent += '<td align="left">' + noOfDays + "</td>";
        } else {
          // var createdDate = getFormattedDate(item.Created);
          // noOfDays = getCalculatedDays(createdDate);

          var createdDate = getFormattedDate(item.Created);
          var requestClosedDate = getFormattedDate(item.RequestClosedDate);
          var calculatedDays = getCalculatedDaysForCompleted(
            createdDate,
            requestClosedDate
          );

          tableContent += '<td align="left">' + calculatedDays + "</td>";
        }

        var region = item.Title;
        if (region == "undefined" || region == null || region == "") {
          region = "";
        }
        tableContent += '<td align="left">' + region + "</td>";

        var fromTeam = item.FromTeam;
        if (fromTeam == "undefined" || fromTeam == null || fromTeam == "") {
          fromTeam = "";
        }
        tableContent += '<td align="left">' + fromTeam + "</td>";

        var subTeam = item.SubTeam;
        if (subTeam == "undefined" || subTeam == null || subTeam == "") {
          subTeam = "";
        }
        tableContent += '<td align="left">' + subTeam + "</td>";

        var fromCompanyCode = item.FromCompanyCode;
        if (
          fromCompanyCode == "undefined" ||
          fromCompanyCode == null ||
          fromCompanyCode == ""
        ) {
          fromCompanyCode = "";
        }
        tableContent += '<td align="left">' + fromCompanyCode + "</td>";

        var subject = item.Subject;
        if (subject == "undefined" || subject == null || subject == "") {
          subject = "";
        }
        tableContent += '<td align="left">' + subject + "</td>";

        var assignedTo = item.AssignedTo;
        if (
          assignedTo == "undefined" ||
          assignedTo == null ||
          assignedTo == ""
        ) {
          assignedTo = "";
        }
        tableContent += '<td align="left">' + assignedTo + "</td>";

        var assignedToPerson = item.AssignedToPerson;
        if (
          assignedToPerson == "undefined" ||
          assignedToPerson == null ||
          assignedToPerson == ""
        ) {
          assignedToPerson = "";
        }
        tableContent += '<td align="left">' + assignedToPerson + "</td>";

        var requestClosedBy = item.RequestClosedBy;
        if (
          requestClosedBy == "undefined" ||
          requestClosedBy == null ||
          requestClosedBy == ""
        ) {
          requestClosedBy = "";
        }
        tableContent += '<td align="left">' + requestClosedBy + "</td>";

        var requestClosedDate = item.RequestClosedDate;
        if (
          requestClosedDate == "undefined" ||
          requestClosedDate == null ||
          requestClosedDate == ""
        ) {
          requestClosedDate = "";
        } else {
          requestClosedDate = getDateTime(item.RequestClosedDate);
        }
        tableContent += '<td align="left">' + requestClosedDate + "</td>";
      });

      //console.log("emailManagementDetails: "+ JSON.stringify(emailManagementDetails));
    },
    error: function (data) {
      console.log(JSON.stringify(error));
    },
  });

  $("#ARIENDataTable").append(tableContent);
}

function getDateTime(date) {
  var now = new Date(date);
  // now = now.toDateString();
  // now = now.toLocaleTimeString();

  console.log("now: " + now);
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var day = now.getDate();
  var hour = now.getHours();
  var minute = now.getMinutes();
  var second = now.getSeconds().toFixed(2);

  if (month.toString().length == 1) {
    month = "0" + month;
  }
  if (day.toString().length == 1) {
    day = "0" + day;
  }
  if (hour.toString().length == 1) {
    hour = "0" + hour;
  }
  if (minute.toString().length == 1) {
    minute = "0" + minute;
  }
  if (second.toString().length == 1) {
    second = "0" + second;
  }
  var dateTime = month + "/" + day + "/" + year + " " + hour + ":" + minute;
  // console.log(dateTime);
  // alert("cashApplicationDate: " + dateTime)
  return dateTime;
}

function getCalculatedDays(createdDate) {
  const date1 = new Date(createdDate);
  const date2 = new Date();

  const difference = date2.getTime() - date1.getTime();
  const days = Math.ceil(difference / (1000 * 3600 * 24));

  return days;
}
function getDateTime(date) {
  var now = new Date(date);
  // now = now.toDateString();
  // now = now.toLocaleTimeString();

  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var day = now.getDate();
  var hour = now.getHours();
  var minute = now.getMinutes();
  var second = now.getSeconds().toFixed(2);

  if (month.toString().length == 1) {
    month = "0" + month;
  }
  if (day.toString().length == 1) {
    day = "0" + day;
  }
  if (hour.toString().length == 1) {
    hour = "0" + hour;
  }
  if (minute.toString().length == 1) {
    minute = "0" + minute;
  }
  if (second.toString().length == 1) {
    second = "0" + second;
  }
  var dateTime = month + "/" + day + "/" + year + " " + hour + ":" + minute;
  // console.log(dateTime);
  // alert("cashApplicationDate: " + dateTime)
  return dateTime;
}

function getCalculatedDaysForCompleted(createdDate, serviceDeskApprovedDate) {
  const date1 = new Date(createdDate);
  const date2 = new Date(serviceDeskApprovedDate);

  const difference = date2.getTime() - date1.getTime();
  const days = Math.ceil(difference / (1000 * 3600 * 24));

  return days;
}

function getFormattedDate(sDate) {
  var date = moment.utc(sDate).format("MM/DD/YYYY");
  var dt = moment(date).date();
  var month = moment(date).month() + 1;
  var year = moment(date).year();

  if (dt < 10) {
    dt = "0" + dt;
  }
  if (month < 10) {
    month = "0" + month;
  }
  // var fDate= year +'-'+ month +'/'+ dt;
  var fDate = month + "/" + dt + "/" + year;
  return fDate;
}
function isMemberOfGroup(GroupName) {
  try {
    var IsMember = false;
    $().SPServices({
      operation: "GetGroupCollectionFromUser",
      webURL: siteUrl,
      userLoginName: $().SPServices.SPGetCurrentUser({
        webURL: siteUrl,
        fieldName: "Name",
      }),
      async: false,
      completefunc: function (xData, Status) {
        if (
          $(xData.responseXML).find("Group[Name='" + GroupName + "']").length ==
          1
        ) {
          IsMember = true;
        }
      },
    });
  } catch (err) {}
  return IsMember;
}
