// var siteUrl = _spPageContextInfo.siteAbsoluteUrl;
var siteUrl = _spPageContextInfo.webServerRelativeUrl;
var emailManagementDetails = [];

$(document).ready(function () {
	getEmailManagementDetails();
 
//sample data source
// const dataSrc = [
// 	{id: 1, title: 'apple', cat: 'fruit'},
// 	{id: 2, title: 'pear', cat: 'fruit'},
// 	{id: 3, title: 'banana', cat: 'fruit'},
// 	{id: 4, title: 'carrot', cat: 'vegie'},
// 	{id: 5, title: 'eggplant', cat: 'vegie'}
// ];
//datatables initialization
const dataTable = $('#tblEmailManagement').DataTable({
	data: emailManagementDetails,
	dom: 'Bfrtip',
	buttons: [	
		'pageLength',	
		'colvis',
		{
			extend: 'excelHtml5',
			exportOptions: {
				columns: ':visible'
			}
		},
	],
	"columnDefs": [{ "targets": -1, "data": null, "defaultContent": "<input id='btnDetails' class='btn btn-success' width='25px' value='Get Details' />"}],
	pageLength: 10,
    lengthMenu: [0, 5, 10, 20, 50, 100, 200, 500],
	// buttons: ['colvis','excel','csv'],
	columns: ['Request #','Req Created on','Req Created by','Req Created Group','Priority','No Of Days','Region','From Team','Sub Team','Comp Code','Subject','Assigned To Team','Assigned To Person','Status','Req Closed By','Req Closed On'].map(header => ({title: header, data: header})),
	// columnDefs: [
	// 	{targets: 0, visible: false}
	// ],
	order: [[0, 'desc']],
	
	// "aoColumns": [
	// 	{ mData: 'Request #' } ,
	// 	{ mData: 'Req Created on' },
	// 	{ mData: 'Req Created by' },
	// 	{ 
	// 	   mData: '',
	// 	   render: (data,type,row) => {
	// 		 return `<a href=${siteUrl+"/SitePages/EmailManagementEdit.aspx?k="}${row.Id}>update</a>`;
	// 	   }
	// 	}
	//   ],
});
//append blank footer to the table
$('#tblEmailManagement').append('<tfoot><tr></tr></tfoot>');
//function to render input elements
const renderTfootInputs =  () => { 
	//grab previous inputs into array
	const prevInputs = [];
	dataTable.columns().every(function(){
		prevInputs.splice(this.index(), 1, $(`#tblEmailManagement tfoot [colindex="${this.index()}"]`).val());
	});
	//purge <tfoot> row contents
	$('#tblEmailManagement tfoot tr').empty()
	//iterate through table columns
	dataTable.columns().every(function(){
		//if the column is visible
		this.visible() ?
		//append corresponding footer <input>
		$('#tblEmailManagement tfoot tr').append(`<th><input colindex="${this.index()}" placeholder="${$(this.header()).text()}" value="${prevInputs[this.index()] || ''}"></input></th>`) :
		true;
	});
};
//initial call of above function
renderTfootInputs();
//call that function each time upon column visibility changes
$('#tblEmailManagement').on('column-visibility.dt', renderTfootInputs);
//individual search
$('#tblEmailManagement').on('keyup', 'tfoot input', function(event){
	dataTable.column($(event.target).attr('colindex')).search($(event.target).val()).draw();
});
});

$('#tblEmailManagement tbody').on('click', 'button', function () {
	var data = table.row($(this).parents('tr')).data();
	alert(data[0] + "'s salary is: " + data[5]);
});

function getEmailManagementDetails(){
  
    var bankURL = siteUrl + "/_api/web/lists/getbytitle('Email Management')/items?$select=ID,Title,FromTeam,FromCompanyCode,Subject,AssignedTo,SubTeam,Priority,CustomerNumber,CustomerName,Description,Status,Created,Author/Title,RequestCreatedGroup,AssignedToPerson,RequestClosedBy,RequestClosedDate&$expand=Author/Title&$orderby=ID asc&$top=1000";   

    return $.ajax({ 
    url: bankURL,   
    type: "GET",  
    async:false,
    contentType: "application/json;odata=verbose",
    headers: { 
      "Accept": "application/json;odata=verbose"
    },  
    success: function(data) { 				
        items = data.d.results.length; //get items count
               
        $.each(data.d.results, function(index, item){

			var noOfDays = 0;
			if(item.Status !== "Completed"){
				var createdDate = getFormattedDate(item.Created);
				var noOfDays = getCalculatedDays(createdDate);				
			
			}else{				
				var createdDate = getFormattedDate(item.Created);
				var noOfDays = getCalculatedDays(createdDate);

				//var createdDate = getFormattedDate(item[i].Created);
				// var serviceDeskApprovedDate = getFormattedDate(objArray[i].ServiceDeskDate);
				// var calculatedDays = getCalculatedDaysForCompleted(createdDate,serviceDeskApprovedDate);
	
				// tableContent += '<td align="left">' + calculatedDays + '</td>';	
			}
			var requestCreatedDate = "";			
			if(item.Created){
				requestCreatedDate = getDateTime(item.Created);	
			}			
           
			var requestClosedBy = "";
			if(item.RequestClosedBy){
				requestClosedBy = item.RequestClosedBy; 
			}

			var requestClosedDate = "";			
			if(item.RequestClosedDate){
				requestClosedDate = getDateTime(item.RequestClosedDate);		
			}


			emailManagementDetails.push({	
				"Id": item.ID,			
				"Request #": item.ID,                    
				"Req Created on": requestCreatedDate,
				"Req Created by": item.Author.Title,
				"Req Created Group": item.RequestCreatedGroup,
				"Priority": item.Priority,
				"No Of Days": noOfDays,
				"Region": item.Title,
				"From Team": item.FromTeam,
				"Sub Team": item.SubTeam,
				"Comp Code": item.FromCompanyCode,
				"Subject": item.Subject,			
				"Assigned To Team": item.AssignedTo,
				"Assigned To Person": item.AssignedToPerson,
				"Status": item.Status,
				"Req Closed By": requestClosedBy,
				"Req Closed On": requestClosedDate
			});
            
		});   
		console.log("emailManagementDetails: "+ JSON.stringify(emailManagementDetails));    
    },  
    error: function(data){
        console.log(JSON.stringify(error));
    }
});  
}

function getDateTime(date) {
	var now     = new Date(date); 
	// now = now.toDateString();
	// now = now.toLocaleTimeString();

	console.log("now: "+ now)
	var year    = now.getFullYear();
	var month   = now.getMonth()+1; 
	var day     = now.getDate();
	var hour    = now.getHours();
	var minute  = now.getMinutes();
	var second  = now.getSeconds().toFixed(2); 

	if(month.toString().length == 1) {
		 month = '0'+month;
	}
	if(day.toString().length == 1) {
		 day = '0'+day;
	}   
	if(hour.toString().length == 1) {
		 hour = '0'+hour;
	}
	if(minute.toString().length == 1) {
		 minute = '0'+minute;
	}
	if(second.toString().length == 1) {
		 second = '0'+second;
	}   
	var dateTime = month+'/'+day+'/'+year +" "+ hour+':'+minute;   
	// console.log(dateTime);
	// alert("cashApplicationDate: " + dateTime)
	 return dateTime;
}

function getCalculatedDays(createdDate){

	const date1 = new Date(createdDate);
	const date2 = new Date();

	const difference = date2.getTime() - date1.getTime();
	const days = Math.ceil(difference / (1000 * 3600 * 24)); 

	return days;
}
function getDateTime(date) {
	var now     = new Date(date); 
	// now = now.toDateString();
	// now = now.toLocaleTimeString();

	console.log("now: "+ now)
	var year    = now.getFullYear();
	var month   = now.getMonth()+1; 
	var day     = now.getDate();
	var hour    = now.getHours();
	var minute  = now.getMinutes();
	var second  = now.getSeconds().toFixed(2); 

	if(month.toString().length == 1) {
		 month = '0'+month;
	}
	if(day.toString().length == 1) {
		 day = '0'+day;
	}   
	if(hour.toString().length == 1) {
		 hour = '0'+hour;
	}
	if(minute.toString().length == 1) {
		 minute = '0'+minute;
	}
	if(second.toString().length == 1) {
		 second = '0'+second;
	}   
	var dateTime = month+'/'+day+'/'+year +" "+ hour+':'+minute;   
	// console.log(dateTime);
	// alert("cashApplicationDate: " + dateTime)
	 return dateTime;
}


function getCalculatedDaysForCompleted(createdDate,serviceDeskApprovedDate){
	const date1 = new Date(createdDate);
	const date2 = new Date(serviceDeskApprovedDate);

	const difference = date2.getTime() - date1.getTime();
	const days = Math.ceil(difference / (1000 * 3600 * 24)); 

	return days;	
}

function getFormattedDate(sDate){		
	var date=moment.utc(sDate).format('MM/DD/YYYY');		
	var dt=moment(date).date();
	var month=moment(date).month()+1;
	var year=moment(date).year();		

	if (dt < 10) {
		dt = '0' + dt;
	}
	if (month < 10) {
		month = '0' + month;
	}
	// var fDate= year +'-'+ month +'/'+ dt;	
	var fDate= month+'/' + dt + '/'+year;
	return fDate;
}


// var listName = "Stop Cash Requests";
// var currentItemID = "";
// var prjID = "";
// var siteUrl = _spPageContextInfo.webServerRelativeUrl;

// let isServiceDeskUser = "";
// let isAPTreasuryUser = "";
// let isCashApplicationUser = "";
// let isStopCashAdmin = "";

// let pendingWithCashApplication = 0;
// var pendingWithAPTreasury = 0;
// var pendingWithServiceDesk = 0;
// var cashApplicationRejected = 0;
// var apTreasuryRejected = 0;
// var serviceDeskRejected = 0;
// var completed = 0;

// //var RestUrl = url + "/_api/web/lists/getbytitle('Audit APP')/items?&$select=ID,AuditNumber,ProjectType,Title,AuditType,AuditStatus,AuditLocation&$filter=(AuditStatus ne 'Deleted')&$top=3000";
// $(document).ready(function() {  
//     bindStatuValues();	

// 	$("#ddlStatus").change(function (){			
// 		$('#tblStatusCount').hide();
// 		pendingWithCashApplication = 0;
// 		pendingWithAPTreasury = 0;
// 		pendingWithServiceDesk = 0;
// 		cashApplicationRejected = 0;
// 		apTreasuryRejected = 0;
// 		serviceDeskRejected = 0;
// 		completed = 0;
// 		var ddlSelectedValue = $('#ddlStatus option:selected').text();	
		
// 		var restUrl = "";
// 		if(ddlSelectedValue != "All"){	

// 			restUrl = siteUrl + "/_api/web/lists/getbytitle('Stop Cash Requests')/items?&$select=ID,Title,VendorNo,VendorName,CompanyCode,ChequeNo,ChequeDate,ChequeAmount,RequestReason,BankAccount,Status&$filter=(Status eq '"+ ddlSelectedValue +"')&$top=5000"; 	
// 			console.log("restUrl: "+restUrl);
// 			bindDataTable(restUrl);
// 		}
// 		else{		
// 			restUrl = siteUrl + "/_api/web/lists/getbytitle('Stop Cash Requests')/items?&$select=ID,Title,VendorNo,VendorName,CompanyCode,ChequeNo,ChequeDate,ChequeAmount,RequestReason,BankAccount,Status&$top=5000"; 	
// 			bindDataTable(restUrl);
// 		}	
// 	});
	
// 	});
	
// 	function bindDataTable(restUrlQuery){
// 		$.ajax({  

//      url: restUrlQuery, 
//      method: "GET", 
//      headers: {  
//        "accept": "application/json;odata=verbose", 
//      },  

//      success: function(data) {  
		
		
// 		$('#stopCashRequestsGrid').empty();

// 		pendingWithCashApplication = 0;
// 		pendingWithAPTreasury = 0;
// 		pendingWithServiceDesk = 0;
// 		cashApplicationRejected = 0;
// 		apTreasuryRejected = 0;
// 		serviceDeskRejected = 0;
// 		completed = 0;

// 		$("#pendingWithCashApplication").text("");
// 		$("#pendingWithAPTreasury").text("");
// 		$("#pendingWithServiceDesk").text("");
// 		$("#cashApplicationRejected").text("");
// 		$("#apTreasuryRejected").text("");
// 		$("#serviceDeskRejected").text("");
// 		$("#completed").text("");

//        if (data.d.results.length > 0) {  
// 		$('#tblStatusCount').show();
	   
//          //construct HTML Table from the JSON Data  
//          $('#stopCashRequestsGrid').append(GenerateTableFromJson(data.d.results));  

//          //Bind the HTML data with Jquery DataTable  

//          var oTable = $('#stopCashRequestsTable').dataTable({  

//            "iDisplayLength": 25,  

//            "aLengthMenu": [  

//              [25, 50, 100],  

//              [25, 50, 100]  

//            ],  

//            "sPaginationType": "full_numbers",
// 			"aaSorting": [ [0,'desc'] ]

//          }); 
// 		$('#stopCashRequestsTable tfoot th').each( function () { 
//         var title = $(this).text(); 
//         $(this).html( '<input type="text" placeholder="Search '+title+'" />' ); 
// 		} ); 
  
// 		// DataTable 
// 		var rtable = $('#stopCashRequestsTable').DataTable(); 
	  
// 		// Apply the search 
// 		rtable.columns().every( function () { 
// 			var that = this; 
	  
// 			$( 'input', this.footer() ).on( 'keyup change', function () { 
// 				if ( that.search() !== this.value ) { 
// 					that 
// 						.search( this.value ) 
// 						.draw(); 
// 				} 
// 			} ); 
// 		} ); 	

//        } else {  

//          $('#stopCashRequestsGrid').append("<span>No Items Found.</span>");  

//        }  

//      },  

//      error: function(data) {
//        $('#stopCashRequestsGrid').append("<span>Error while Retrieving Stop Cash Requests. Error : " + JSON.stringify(data) + "</span>");  
//     }  

// 	});  
		
// 	}
// 	function GenerateTableFromJson(objArray) {
	
// 	if(isStopCashAdmin){		

// 		var tableContent = '<table id="stopCashRequestsTable" class="baxstyles"><thead><tr><th style="display:none;">Request Id</th>'+'<th>Detail View</th>'+'<th>Detail Update</th>'+'<th>Delete</th>'+'<th align="left">Request No'+'<th align="left">Request Status'+'<th align="left">Request Type</th>'+'<th align="left">Vendor No</th>'+'<th align="left">Vendor Name</th>'+'<th align="left">Company Code</th>'+'<th align="left">Check No</th>'+'<th align="left">Check Date</th>'+'<th align="left">Check Amount</th>'+'<th align="left">Bank Account</th>'+'<th align="left">Request Reason</th></tr></thead><tfoot><tr><th style="display:none;">Request Id</th>'+'<th></th>'+'<th></th>'+'<th></th>'+'<th align="left">Request No'+'<th align="left">Request Status'+'<th align="left">Request Type</th>'+'<th align="left">Vendor No</th>'+'<th align="left">Vendor Name</th>'+'<th align="left">Company Code</th>'+'<th align="left">Check No</th>'+'<th align="left">Check Date</th>'+'<th align="left">Check Amount</th>'+'<th align="left">Bank Account</th>'+'<th align="left">Request Reason</th></tr></tfoot><tbody>';  

// 	}else if(isServiceDeskUser || isCashApplicationUser || isAPTreasuryUser){		

// 		var tableContent = '<table id="stopCashRequestsTable" class="baxstyles"><thead><tr><th style="display:none;">Request Id</th>'+'<th>Detail View</th>'+'<th>Detail Update</th>'+'<th align="left">Request No'+'<th align="left">Request Status'+'<th align="left">Request Type</th>'+'<th align="left">Vendor No</th>'+'<th align="left">Vendor Name</th>'+'<th align="left">Company Code</th>'+'<th align="left">Check No</th>'+'<th align="left">Check Date</th>'+'<th align="left">Check Amount</th>'+'<th align="left">Bank Account</th>'+'<th align="left">Request Reason</th></tr></thead><tfoot><tr><th style="display:none;">Request Id</th>'+'<th>Detail View</th>'+'<th>Detail Update</th>'+'<th align="left">Request No'+'<th align="left">Request Status'+'<th align="left">Request Type</th>'+'<th align="left">Vendor No</th>'+'<th align="left">Vendor Name</th>'+'<th align="left">Company Code</th>'+'<th align="left">Check No</th>'+'<th align="left">Check Date</th>'+'<th align="left">Check Amount</th>'+'<th align="left">Bank Account</th>'+'<th align="left">Request Reason</th></tr></tfoot><tbody>';
		
// 	}	
	
//     for (var i = 0; i < objArray.length; i++) {  

		
		
// 		tableContent += '<tr>'; 

// 		if(isStopCashAdmin){
// 			tableContent += '<td>' + "<input type='image' id='btnView' width='50' height='30' src='/sites/US_ARO_Offshore/KranthiDemoSite/SiteAssets/View.png'/>" + '</td>';	
				
// 			tableContent += '<td>' + "<input type='image' id='btnUpdate' width='50' height='30' src='/sites/US_ARO_Offshore/KranthiDemoSite/SiteAssets/item-edit.png'/>" + '</td>';		
// 			tableContent += '<td>' + "<input type='image' id='btnDelete' width='50' height='30' src='/sites/US_ARO_Offshore/KranthiDemoSite/SiteAssets/delete.png'/>" + '</td>';
// 		}else if(isServiceDeskUser || isCashApplicationUser || isAPTreasuryUser){
// 			tableContent += '<td>' + "<input type='image' id='btnView' width='50' height='30' src='/sites/US_ARO_Offshore/KranthiDemoSite/SiteAssets/View.png'/>" + '</td>';	
// 			tableContent += '<td>' + "<input type='image' id='btnUpdate' width='50' height='30' src='/sites/US_ARO_Offshore/KranthiDemoSite/SiteAssets/item-edit.png'/>" + '</td>';	
// 		}		

// 		tableContent += '<td class="nr" style="display:none;">' + objArray[i].ID + '</td>';  

// 		var requestIDNumber = objArray[i].ID;		
// 		if(requestIDNumber == null || requestIDNumber == "")
// 		{			
// 			requestIDNumber = "";
// 		}		
//         tableContent += '<td class="requestIDNumber" align="left">' + requestIDNumber + '</td>';

// 		var requestStatus = objArray[i].Status;
// 		if(requestStatus == "undefined" || requestStatus == null || requestStatus == "")
// 		{
// 			requestStatus = "";
// 		}else{
// 			if(requestStatus === "Pending with Cash Application"){
// 				pendingWithCashApplication++;
// 			}else if(requestStatus === "Pending with AP Treasury")	{
// 				pendingWithAPTreasury++; 
// 			}else if(requestStatus === "Pending with Service Desk"){
// 				pendingWithServiceDesk++;
// 			}else if(requestStatus === "Cash Application Rejected")	{
// 				cashApplicationRejected++;
// 			}else if(requestStatus === "AP Treasury Rejected"){
// 				apTreasuryRejected++;				
// 			}else if(requestStatus === "Service Desk Rejected"){
// 				serviceDeskRejected++;
// 			}else if(requestStatus === "Completed"){
// 				completed++;
// 			}
// 		}
// 		tableContent += '<td align="left">' + requestStatus + '</td>';

// 		var requestType = objArray[i].Title;
// 		if(requestType == "undefined" || requestType == null || requestType == "")
// 		{
// 			requestType = "";
// 		}
// 		tableContent += '<td align="left">' + requestType + '</td>';
		
// 		var vendorNo = objArray[i].VendorNo;
// 		if(vendorNo == "undefined" || vendorNo == null || vendorNo == "")
// 		{
// 			vendorNo = "";
// 		}
// 		tableContent += '<td align="left">' + vendorNo + '</td>';
		
// 		var vendorName = objArray[i].VendorName;
// 		if(vendorName == "undefined" || vendorName == null || vendorName == "")
// 		{
// 			vendorName = "";
// 		}
// 		tableContent += '<td align="left">' + vendorName + '</td>';
		
// 		var companyCode = objArray[i].CompanyCode;
// 		if(companyCode == "undefined" || companyCode == null || companyCode == "")
// 		{
// 			companyCode = "";
// 		}
// 		tableContent += '<td align="left">' + companyCode + '</td>';

//         var chequeNo = objArray[i].ChequeNo;
// 		if(chequeNo == "undefined" || chequeNo == null || chequeNo == "")
// 		{
// 			chequeNo = "";
// 		}
// 		tableContent += '<td align="left">' + chequeNo + '</td>';

//         var chequeDate = objArray[i].ChequeDate;
// 		if(chequeDate == "undefined" || chequeDate == null || chequeDate == "")
// 		{
// 			chequeDate = "";
// 		}
// 		tableContent += '<td align="left">' + chequeDate + '</td>';

//         var chequeAmount = objArray[i].ChequeAmount;
// 		if(chequeAmount == "undefined" || chequeAmount == null || chequeAmount == "")
// 		{
// 			chequeAmount = "";
// 		}
// 		tableContent += '<td align="left">' + chequeAmount + '</td>';

//         var bankAccount = objArray[i].BankAccount;
// 		if(bankAccount == "undefined" || bankAccount == null || bankAccount == "")
// 		{
// 			bankAccount = "";
// 		}
// 		tableContent += '<td align="left">' + bankAccount + '</td>';

//         var requestReason = objArray[i].RequestReason;
// 		if(requestReason == "undefined" || requestReason == null || requestReason == "")
// 		{
// 			requestReason = "";
// 		}
// 		tableContent += '<td align="left">' + requestReason + '</td>';	

			
// 		tableContent += '</tr>';
//      }

// 	 $("#pendingWithCashApplication").text(pendingWithCashApplication);
// 	 $("#pendingWithAPTreasury").text(pendingWithAPTreasury);
// 	 $("#pendingWithServiceDesk").text(pendingWithServiceDesk);
// 	 $("#cashApplicationRejected").text(cashApplicationRejected);
// 	 $("#apTreasuryRejected").text(apTreasuryRejected);
// 	 $("#serviceDeskRejected").text(serviceDeskRejected);
// 	 $("#completed").text(completed);


//      return tableContent;
//    }    

// 	$( "table" ).delegate( "#btnView", "click", function(e) {
// 	  var $row = $(this).closest("tr");	
// 	  var $ItemID = $row.find(".nr").text();    
// 	  window.location.replace(siteUrl + '/SitePages/StopCashRequestsView.aspx?k='+$ItemID); 
// 	  e.preventDefault();

// 	});

// 	$( "table" ).delegate( "#btnUpdate", "click", function(e) {
// 	  var $row = $(this).closest("tr");
// 	  var $ItemID = $row.find(".nr").text();  
// 	  window.location.replace(siteUrl + '/SitePages/StopCashRequestsEdit.aspx?k='+$ItemID);   
// 	  e.preventDefault();

// 	});

// 	$( "table" ).delegate( "#btnDelete", "click", function(e) {
// 	  var $row = $(this).closest("tr");
// 	  var $ItemID = $row.find(".nr").text();  
// 	  currentItemID=$ItemID;
// 	  var $text = $row.find(".requestIDNumber").text();
// 	  DeleteRecord($ItemID); 
// 	  e.preventDefault();

// 	});

// 	function DeleteRecord(listItemID)     
// 	{  
// 		$.ajax  
// 		({
// 			url: siteUrl + "/_api/web/lists/GetByTitle('"+ listName +"')/items("+ listItemID +")",
// 			type: "POST",  
// 			headers:  
// 			{  
// 				"Accept": "application/json;odata=verbose",
// 				"X-RequestDigest": $("#__REQUESTDIGEST").val(),
// 				"IF-MATCH": "*",
// 				"X-HTTP-Method" :"DELETE" 
// 			},  
// 			success: function(data, status, xhr)  
// 			{  
// 				alert("Stop Cash Request has been deleted successfully!");
// 				location.reload();
// 			},  
// 			error: function(xhr, status, error)  
// 			{ 
// 				alert("Delete Function Failed for "+ listName +" list for item ID: " + listItemID);  
// 			}  
// 		});  
// 	}


// function IsOwnerOfGroup(GroupName)
// {	
// try{
// 		var IsMember = false; 
// 	$().SPServices({
// 			operation: "GetGroupCollectionFromUser",
// 			webURL: _spPageContextInfo.webServerRelativeUrl,
// 			userLoginName: $().SPServices.SPGetCurrentUser({
// 				webURL: _spPageContextInfo.webServerRelativeUrl,fieldName:"Name"}
// 			), 
// 			async: false,
// 			completefunc: function (xData, Status) {            	      
// 				if ($(xData.responseXML).find("Group[Name='"+ GroupName +"']").length == 1) {
// 					IsMember= true;
// 				}                
// 			}
// 		});
// 	}catch(err){}
// 	return IsMember;
// }	

// function isMemberOfGroup(GroupName)
// {	
// try{
// 	var IsMember = false; 
// 	$().SPServices({
// 			operation: "GetGroupCollectionFromUser",
// 			webURL: _spPageContextInfo.webServerRelativeUrl,
// 			userLoginName: $().SPServices.SPGetCurrentUser({
// 				webURL: _spPageContextInfo.webServerRelativeUrl,fieldName:"Name"}
// 			), 
// 			async: false,
// 			completefunc: function (xData, Status) {            	      
// 				if ($(xData.responseXML).find("Group[Name='"+GroupName+"']").length == 1) {
// 					IsMember= true;
// 				}                
// 			}
// 		});
// 	}catch(err){}
// 	return IsMember;
// }

// function bindStatuValues(){
// 	$("#tblStatusCount").hide();
// 	var inputStatus = '<select id="ddlStatusNew" class="col-xs-4"> <option value="" selected>All</option>'; 
// 	groupNames = ["Service Desk","AP Treasury","Cash Application","Stop Cash Admins"];

// 	for(var i = 0; i < groupNames.length; i++){		
		
//         if(i === 0){
//             isServiceDeskUser = isMemberOfGroup("Service Desk");
			
//         }if(i === 1){
//             isAPTreasuryUser = isMemberOfGroup("AP Treasury");
			
//         }if(i === 2){
//             isCashApplicationUser = isMemberOfGroup("Cash Application");
			
//         }if(i === 3){
//             isStopCashAdmin = isMemberOfGroup("Stop Cash Admins");			
//         }

// 		if(isServiceDeskUser){
// 			inputStatus += '<option value="Pending with Service Desk">Pending with Service Desk</option>';
// 			inputStatus += '<option value="Cash Application Rejected">Cash Application Rejected</option>';
// 			break;
// 		}else if(isAPTreasuryUser){
// 			inputStatus += '<option value="Pending with AP Treasury">Pending with AP Treasury</option>';
// 			inputStatus += '<option value="Service Desk Rejected">Service Desk Rejected</option>';
// 			break;
// 		}else if(isCashApplicationUser){
// 			inputStatus += '<option value="Pending with Cash Application">Pending with Cash Application</option>';
// 			inputStatus += '<option value="AP Treasury Rejected">AP Treasury Rejected</option>';
// 			break;
// 		}else if(isStopCashAdmin){
// 			inputStatus += '<option value="Pending with Cash Application">Pending with Cash Application</option>';
// 			inputStatus += '<option value="Pending with AP Treasury">Pending with AP Treasury</option>';
// 			inputStatus += '<option value="Pending with Service Desk">Pending with Service Desk</option>';
// 			inputStatus += '<option value="Cash Application Rejected">Cash Application Rejected</option>';
// 			inputStatus += '<option value="AP Treasury Rejected">AP Treasury Rejected</option>';
// 			inputStatus += '<option value="Service Desk Rejected">Service Desk Rejected</option>';
// 			inputStatus += '<option value="Completed">Completed</option>';
// 			break;
// 		}

//     }
// 	inputStatus += '</select>'; 
// 	$('#ddlStatus').append(inputStatus);
	

//     console.log("isServiceDeskUser: "+isServiceDeskUser);
//     console.log("isAPTreasuryUser: "+isAPTreasuryUser);
//     console.log("isCashApplicationUser: "+isCashApplicationUser);
//     console.log("isStopCashAdmin: "+isStopCashAdmin);
// }

// function bindYear(){
// var yearDetailsURL= siteUrl + "/_api/web/lists/getbytitle('Audit APP')/items?&$select=ID,Year&$top=5000";
// $.ajax({ 
// 	url: yearDetailsURL,   
// 	type: "GET",  
// 	async:false,
// 	contentType: "application/json;odata=verbose",
// 	headers: { 
// 		"Accept": "application/json;odata=verbose"
// 	},  
// 	success: function(data) { 
// 	yearValues=[];
// 	yearUniqueDetails=[];		
// 	items = data.d.results.length; //get items count
// 	var inputYear = '<select id="ddlYearNew" class="col-xs-4"> <option value="">All</option>'; 

// 	$.each(data.d.results, function(index, item){
// 		var yearVal=item.Year;			
// 		if(yearVal!=null && yearVal!=undefined){					
// 			yearValues.push(item.Year);				
// 		}
				
// 	});
	
// 	if(yearValues.length>0){
// 		$.each(yearValues, function(i, el){
// 			if($.inArray(el, yearUniqueDetails) === -1) yearUniqueDetails.push(el);
// 		});			
// 		for(var e=0;e<yearUniqueDetails.length;e++){
// 			inputYear += '<option value="' + yearUniqueDetails[e] + '"selected>' + yearUniqueDetails[e] + '</option>'; 	
// 		}
// 	}
// 	inputYear += '</select>'; 
// 	$('#ddlYear').append(inputYear);
	
// 	$("#ddlYearNew").each(function () {   
// 	$('option', this).each(function () {
// 	if ($(this).text() =="All") {   
// 		$(this).attr('selected', 'selected')  
// 		};  
// 		}); 
// 	});
	
// 	},  
// 	error: function(data){
// 		console.log(JSON.stringify(error));
// 	}
// });
// }
