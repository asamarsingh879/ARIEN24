// var siteUrl = _spPageContextInfo.siteAbsoluteUrl;
var siteUrl = _spPageContextInfo.webServerRelativeUrl;
var listName = "Stop Cash Requests";
var groupName = "Service Desk"
var groupNames = ["Service Desk","AP Treasury","Cash Application","Stop Cash Admins"];
let isServiceDeskUser = "";
let isAPTreasuryUser = "";
let isCashApplicationUser = "";
let isStopCashAdmin = "";
let statusVal = "";
var queryStrVal = [];
var btnStatus = "";
var attachmentId = "";
var attachmentTitle = "";

$(document).ready(function () {

    getQueryStrVal();
    for(var i = 0; i < groupNames.length; i++){
        if(i === 0){
            isServiceDeskUser = isMemberOfGroup(groupNames[i]);
        }
        if(i === 1){
            isAPTreasuryUser = isMemberOfGroup(groupNames[i]);
        }
        if(i === 2){
            isCashApplicationUser = isMemberOfGroup(groupNames[i]);
        }
        if(i === 3){
            isStopCashAdmin = isMemberOfGroup(groupNames[i]);
        }
    }
    //hideShowButtons();

    // $("#cashApplicationTab").hide();
    // $("#APTreasuryTab").hide();
    // $("#serviceDeskTab").hide();

    $("#btnUpdate").hide();
    $("#btnApprove").hide();
    $("#btnReject").hide();
   
    $("#divStopCashRequirements").hide();
    $("#divUnauthorizedMessage").hide();        
    $("#checkDateInput").datepicker();
    
    if(isServiceDeskUser || isAPTreasuryUser || isCashApplicationUser){
        $("#divStopCashRequirements").show(); 
        $("#divUnauthorizedMessage").hide();           
    }else{
        $("#divStopCashRequirements").hide(); 
        $("#divUnauthorizedMessage").show();       
    }
   

    // document.getElementById("myBtn").disabled = true;
    // ExecuteOrDelayUntilScriptLoaded(getProjectTypeValues,"sp.js"); 		
    //ExecuteOrDelayUntilScriptLoaded(getAuditTypeValues,"sp.js");	
    
    $("#btnUpdate").click(function(){	
        
        var requestTypeVal = $("#requestTypeInput").val();
        var vendorNoVal = $("#vendorNoInput").val();
        var vendorNameVal = $("#vendorNameInput").val();
        var companyCodeVal = $("#companyCodeInput").val();
        var chequeNoVal = $("#chequeNoInput").val();
        var chequeDateVal = $("#chequeDateInput").val();
        var chequeAmountVal = $("#chequeAmountInput").val();
        var bankAccountVal = $("#bankAccountInput").val();   
        var requestReasonVal = $("#requestReasonInput").val();
        

        if(requestTypeVal && vendorNoVal && vendorNameVal && companyCodeVal && chequeNoVal && chequeDateVal && chequeAmountVal && requestReasonVal && bankAccountVal){
            if(isCashApplicationUser && statusVal === "Pending with Cash application"){
                var cashApplicationAttachments = "";
                var cashApplicationRemarks =  $("#cashApplicationInput").val();

                var input = document.getElementById("cashApplicationAttachments");
                var fileCount = input.files.length;  
                
                if(fileCount > 0 && cashApplicationRemarks){
                    updateRequest(requestTypeVal,vendorNoVal,vendorNameVal,companyCodeVal,chequeNoVal,chequeDateVal,chequeAmountVal,requestReasonVal,bankAccountVal,cashApplicationRemarks);

                }else{
                    alert("Please fill all mandatory columns in Cash Application section");
                }
            }
            //addItemToList(requestTypeVal,vendorNoVal,vendorNameVal,companyCodeVal,chequeNoVal,chequeDateVal,chequeAmountVal,requestReasonVal,bankAccountVal);
        }else{
            alert("Stop Cash Request form is incomplete. Please fill all mandatory columns!");
        }    
    });	
    
    $("#btnApprove").click(function(){
        btnStatus = "approve";
        if(isCashApplicationUser && statusVal === "Pending with Cash Application"){
            
            var cashApplicationRemarks =  $("#cashApplicationInput").val();

            var input = document.getElementById("cashApplicationAttachments");
            var fileCount = input.files.length;  
            
            if(fileCount > 0 && cashApplicationRemarks){
                var status = "Pending with AP Treasury";              

                attachmentId = "cashApplicationAttachments";
                attachmentTitle = "Cash Application";
                updateRequestStatus(status);
            }else{
                alert("Please fill all mandatory columns in Cash Application section");
            }
        }
        if(isAPTreasuryUser && statusVal === "Pending with AP Treasury"){
            
            var APTreasuryRemarks =  $("#APTreasuryInput").val();

            var input = document.getElementById("APTreasuryAttachments");
            var fileCount = input.files.length;  
            
            if(fileCount > 0 && APTreasuryRemarks){
                var status = "Pending with Service Desk"; 

                attachmentId = "APTreasuryAttachments";
                attachmentTitle = "AP Treasury";
                updateRequestStatus(status);
            }else{
                alert("Please fill all mandatory columns in AP Treasury section");
            }
        }
        if(isServiceDeskUser && statusVal === "Pending with Service Desk"){
            
            var serviceDeskRemarks =  $("#serviceDeskInput").val();

            var input = document.getElementById("serviceDeskAttachments");
            var fileCount = input.files.length;  
            
            if(fileCount > 0 && serviceDeskRemarks){
                var status = "Completed";
                attachmentId = "serviceDeskAttachments";
                attachmentTitle = "Service Desk";

                updateRequestStatus(status);
            }else{
                alert("Please fill all mandatory columns in Service Desk section");
            }
        }
    });

    $("#btnReject").click(function(){
        btnStatus = "rejected";
        if(isCashApplicationUser && statusVal === "Pending with Cash Application"){
            
            var cashApplicationRemarks =  $("#cashApplicationInput").val();

            var input = document.getElementById("cashApplicationAttachments");
            var fileCount = input.files.length;  
            
            if(fileCount > 0 && cashApplicationRemarks){
                var status = "Cash Application rejected";               
                updateRequestStatus(status);

            }else{
                alert("Please fill all mandatory columns in Cash Application section");
            }
        }
        if(isAPTreasuryUser && statusVal === "Pending with AP Treasury"){
            
            var APTreasuryRemarks =  $("#APTreasuryInput").val();

            var input = document.getElementById("APTreasuryAttachments");
            var fileCount = input.files.length;  
            
            if(fileCount > 0 && APTreasuryRemarks){
                var status = "AP Treasury rejected";               
                updateRequestStatus(status);

            }else{
                alert("Please fill all mandatory columns in AP Treasury section");
            }
        }
        if(isServiceDeskUser && statusVal === "Pending with Service Desk"){
            
            var serviceDeskRemarks =  $("#serviceDeskInput").val();

            var input = document.getElementById("serviceDeskAttachments");
            var fileCount = input.files.length;  
            
            if(fileCount > 0 && serviceDeskRemarks){
                var status = "Service Desk rejected";               
                updateRequestStatus(status);

            }else{
                alert("Please fill all mandatory columns in Service Desk section");
            }
        }
    });
    
});

function updateRequestStatus(status){
    try {				
            // var loginuserid = _spPageContextInfo.userId;    
            var cashApplicationRemarks =  $("#cashApplicationInput").val();
            var APTreasuryRemarks =  $("#APTreasuryInput").val();
            var serviceDeskRemarks =  $("#serviceDeskInput").val();

			var queryUrl = siteUrl +"/_api/web/lists/getbytitle('Stop Cash Requests')/items('"+ queryStrVal +"')";

            $.ajax({
                url:queryUrl, // list item ID  
                type: "POST", 
                async:false,
                data: JSON.stringify  
                ({ 
                    '__metadata': {
                        'type': 'SP.Data.StopCashRequestsListItem'
                    },
                        'Status': status, 
                        'CashApplicationRemarks': cashApplicationRemarks,
                        'APTreasuryRemarks': APTreasuryRemarks,
                        'ServiceDeskRemarks': serviceDeskRemarks
                    }),
                    headers:  
					{  
						"Accept": "application/json;odata=verbose",  
						"Content-Type": "application/json;odata=verbose",  
						"X-RequestDigest": $("#__REQUESTDIGEST").val(),  
						"IF-MATCH": "*",  
						"X-HTTP-Method": "MERGE"  
					},success:onQuerySuccessUpdate,
                    error: onQueryFailureUpdate
            });
        }
        catch (ex) {
            console.log("Exception" + ex.message);
            alert("Exception" + ex.message);
        }
}
function onQuerySuccessUpdate() {       

    ///uploadCashApplicationAttachments();
   // alert("Test");

    if(btnStatus === "approve"){
        readFile(attachmentId, attachmentTitle);
    }
 

    var url = siteUrl + "/SitePages/StopCashRequestsDashboard.aspx";
        
    var alertMessage="Stop Cash Request has been "+ btnStatus +" successfully";
        BootstrapDialog.show({
        message:alertMessage,
        animate: false,
        buttons: [{
            label: 'Close',
            action: function(dialogRef){
                dialogRef.close();                
                $(location).attr('href',url);
            }
        }]
    });

  location.reload();
}
function onQueryFailureUpdate(error) {
    alert(JSON.stringify(error));
}
function updateRequest(requestTypeVal,vendorNoVal,vendorNameVal,companyCodeVal,chequeNoVal,chequeDateVal,chequeAmountVal,requestReasonVal,bankAccountVal,cashApplicationRemarks){
    try {				
            var loginuserid = _spPageContextInfo.userId;
                            
            //var queryUrl = siteUrl +"/_api/web/lists/getbytitle('Stop Cash Requests')/items";

            
			var queryUrl = siteUrl +"/_api/web/lists/getbytitle('Stop Cash Requests')/items('"+queryStrVal+"')";

            $.ajax({
                url:queryUrl, // list item ID  
                type: "POST", 
                async:false,
                data: JSON.stringify  
                ({ 
                    '__metadata': {
                        'type': 'SP.Data.StopCashRequestsListItem'
                    },
                       
                        'Title': requestTypeVal,
                        'VendorNo': vendorNoVal,  
                        'VendorName': vendorNameVal,
                        'CompanyCode': companyCodeVal,
                        'ChequeNo': chequeNoVal,
                        'ChequeDate': chequeDateVal,  
                        'ChequeAmount': chequeAmountVal,
                        'RequestReason': requestReasonVal,
                        'BankAccount': bankAccountVal,
                        'CashApplicationRemarks': cashApplicationRemarks
                    }),
                    headers:  
					{  
						"Accept": "application/json;odata=verbose",  
						"Content-Type": "application/json;odata=verbose",  
						"X-RequestDigest": $("#__REQUESTDIGEST").val(),  
						"IF-MATCH": "*",  
						"X-HTTP-Method": "MERGE"  
					},success:onQuerySuccess,
                    error: onQueryFailure
            });
        }
        catch (ex) {
            console.log("Exception" + ex.message);
            alert("Exception" + ex.message);
        }
}
function onQuerySuccess() {       

    ///uploadCashApplicationAttachments();

    readFile("cashApplicationAttachments", "Cash Application");

    var url = siteUrl + "/SitePages/StopCashRequestsDashboard.aspx";
        
    var alertMessage="Stop Cash Request has been approved successfully";
        BootstrapDialog.show({
        message:alertMessage, 
        animate: false,
        buttons: [{
            label: 'Close',
            action: function(dialogRef){
                dialogRef.close();                
                $(location).attr('href',url);
            }
        }]
    });

    $("#requestTypeInput").val("");
    $("#vendorNoInput").val("");
    $("#vendorNameInput").val("");
    $("#companyCodeInput").val("");
    $("#checkNoInput").val("");
    $("#checkDateInput").val("");
    $("#checkAmountInput").val("");
    $("#bankAccountInput").val("");   
    $("#requestReasonInput").val("");
    $("#cashApplicationRemarks").val("");
}
function onQueryFailure(error) {
    alert(JSON.stringify(error));
}

function isMemberOfGroup(GroupName)
{	
try{
	var IsMember = false; 
	$().SPServices({
			operation: "GetGroupCollectionFromUser",
			webURL: _spPageContextInfo.webServerRelativeUrl,
			userLoginName: $().SPServices.SPGetCurrentUser({
				webURL: _spPageContextInfo.webServerRelativeUrl,fieldName:"Name"}
			), 
			async: false,
			completefunc: function (xData, Status) {            	      
				if ($(xData.responseXML).find("Group[Name='"+GroupName+"']").length == 1) {
					IsMember= true;
				}                
			}
		});
	}catch(err){}
	return IsMember;
}

function getFormattedDate(sDate){		
    var date=moment.utc(sDate).format('MM/DD/YYYY');		
    var dt=moment(date).date();
    var month=moment(date).month()+1;
    var year=moment(date).year();		

    if (dt < 10) {
    dt = '0' + dt;
    }
    if (month < 10) {
    month = '0' + month;
}
var fDate= month+'/' + dt + '/'+year;	
return fDate;
}

function readFile(getfileName,FieldTitleVal){  	
    //Get File Input Control and read th file name  
    var element = document.getElementById(getfileName);  
    var file = element.files[0];  
    var parts = element.value.split("\\");  
    var fileName = parts[parts.length - 1];  
    //Read File contents using file reader  
    var reader = new FileReader();  
    reader.onload = function(e)  
    {  
        uploadFile(e.target.result, fileName,FieldTitleVal);  
    }  
    reader.onerror = function(e)  
    {  
        alert(e.target.error);  
    }  
    reader.readAsArrayBuffer(file);  
}  

function uploadFile(arrayBuffer, fileName,FieldTitleVal){  
    //Get Client Context,Web and List object.  
    var clientContext = new SP.ClientContext();  
    var oWeb = clientContext.get_web();  
    var oList = oWeb.get_lists().getByTitle('StopCashRequestAttachments');  
    //Convert the file contents into base64 data  
    var bytes = new Uint8Array(arrayBuffer);  
    var i, length, out = '';  
    for (i = 0, length = bytes.length; i < length; i += 1)  
    {  
        out += String.fromCharCode(bytes[i]);  
    }  
    var base64 = btoa(out);  
    //Create FileCreationInformation object using the read file data  
    var createInfo = new SP.FileCreationInformation();  
    createInfo.set_content(base64);  
    createInfo.set_url(fileName);  
    //Add the file to the library  
    var uploadedDocument = oList.get_rootFolder().get_files().add(createInfo);
    var myListItem = uploadedDocument.get_listItemAllFields();
    myListItem.set_item("Title", FieldTitleVal);		
    myListItem.set_item("ItemID", queryStrVal.k);		
    myListItem.update();     

   //Load client context and execcute the batch  
    clientContext.load(uploadedDocument);  
    clientContext.executeQueryAsync(QuerySuccess, QueryFailure);  
}  

function QuerySuccess()  
{  
    console.log('File Uploaded Successfully.');  
}  

function QueryFailure(sender, args)  
{  
    console.log('Request failed with error message - ' + args.get_message() + ' . Stack Trace - ' + args.get_stackTrace());  
}
function handleFileSelect(e) {
    var files = e.target.files;
    var filesArr = Array.prototype.slice.call(files);
    filesArr.forEach(function(f) {          
        storedFiles.push(f);            
        var reader = new FileReader();
        reader.onload = function (e) {
            //var html = "<div><img src='/sites/Audit_Project_Mgmt/scripts/images/delete.png' class='selFile' title='Click to remove'>" + f.name + "<br clear=\"left\"/></div>";
            //selDiv.append(html);                
        }
        reader.readAsDataURL(f); 
    });        
}
    
function handleForm(e) {
    e.preventDefault();
    var data = new FormData();        
    for(var i=0, len=storedFiles.length; i<len; i++) {
        data.append('files', storedFiles[i]); 
    }        
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'handler.cfm', true);        
    xhr.onload = function(e) {
        if(this.status == 200) {
            console.log(e.currentTarget.responseText);  
            alert(e.currentTarget.responseText + ' items uploaded.');
        }
    }        
    xhr.send(data);
}
    
function removeFile(e) {
    var file = $(this).data("file");
    for(var i=0;i<storedFiles.length;i++) {
        if(storedFiles[i].name === file) {
            storedFiles.splice(i,1);
            break;
        }
    }
    $(this).parent().remove();
}

function retrieveStopCashRequestsDetails(){ 	
    restUrl = siteUrl + "/_api/web/lists/getbytitle('Stop Cash Requests')/items?&$select=ID,Title,VendorNo,VendorName,CompanyCode,ChequeNo,ChequeDate,ChequeAmount,RequestReason,BankAccount,Status,CashApplicationRemarks,APTreasuryRemarks,ServiceDeskRemarks&$filter=(ID eq '"+ queryStrVal +"')&$top=5000";
    return $.ajax({ 
		url: restUrl,   
		type: "GET",
		async:false,	
		contentType: "application/json;odata=verbose",
		headers: { 
          "Accept": "application/json;odata=verbose"
		},  
		success: function(data) { 
		items = data.d.results.length; 
		$.each(data.d.results, function(index, item){		
		
            if(item.Title){
                $("#requestTypeInput").val(item.Title);
            }
            if(item.VendorNo){
                $("#vendorNoInput").val(item.VendorNo);
            }
            if(item.VendorName){
                $("#vendorNameInput").val(item.VendorName); 
            }
            if(item.CompanyCode){
                $("#companyCodeInput").val(item.CompanyCode);
            }
            if(item.ChequeNo){
                $("#chequeNoInput").val(item.ChequeNo);
            }
            if(item.ChequeDate){
                var chequeDateVal = getFormattedDate(item.ChequeDate);

                $("#chequeDateInput").val(chequeDateVal);
            }
            if(item.ChequeAmount){
                $("#chequeAmountInput").val(item.ChequeAmount);
            }
            if(item.BankAccount){
                $("#bankAccountInput").val(item.BankAccount);
            }
            if(item.RequestReason){
                $("#requestReasonInput").val(item.RequestReason);                
            }
            if(item.CashApplicationRemarks){
                $("#cashApplicationInput").val(item.CashApplicationRemarks);                
            }
            if(item.APTreasuryRemarks){
                $("#APTreasuryInput").val(item.APTreasuryRemarks);                
            }
            if(item.ServiceDeskRemarks){
                $("#serviceDeskInput").val(item.ServiceDeskRemarks);                
            }
            if(item.Status){
                $("#cashApplicationTab").hide();
                $("#APTreasuryTab").hide();
                $("#serviceDeskTab").hide();

                $("#btnUpdate").hide();
                $("#btnApprove").hide();
                $("#btnReject").hide();

                statusVal = item.Status;
                if(statusVal === "Pending with Cash Application"){
                    $("#btnApprove").show();
                    $("#btnReject").show();
                    $("#cashApplicationTab").show();
                }else if(statusVal === "Cash Application Rejected"){
                    $("#btnUpdate").show();   
                    $("#cashApplicationTab").hide();
                }else if(statusVal === "Pending with AP Treasury"){
                    $("#btnApprove").show();
                    $("#btnReject").show();

                   
                    $("#cashApplicationAttachments").hide();
                    $("#cashApplicationAttachmentsGrid").show();

                    getAttachments(queryStrVal, "Cash Application", "cashApplicationAttachmentsGrid");
                    document.getElementById('cashApplicationInput').setAttribute('readonly', true);

                    $("#cashApplicationTab").show();
                    $("#APTreasuryTab").show();
                }else if(statusVal === "AP Treasury Rejected"){
                    $("#btnApprove").show();
                    $("#btnReject").show();
                    $("#cashApplicationTab").show();
                }else if(statusVal === "Pending with Service Desk"){
                    $("#btnApprove").show();
                    $("#btnReject").show();

                    $("#cashApplicationAttachments").hide();
                    $("#cashApplicationAttachmentsGrid").show();


                    $("#APTreasuryAttachments").hide();
                    $("#APTreasuryAttachmentsGrid").show();


                    getAttachments(queryStrVal, "Cash Application", "cashApplicationAttachmentsGrid");
                    document.getElementById('cashApplicationInput').setAttribute('readonly', true);

                    getAttachments(queryStrVal, "AP Treasury", "APTreasuryAttachmentsGrid");
                    document.getElementById('APTreasuryInput').setAttribute('readonly', true);

                    $("#cashApplicationTab").show();
                    $("#APTreasuryTab").show();
                    $("#serviceDeskTab").show();

                }else if(statusVal === "Service Desk Rejected"){
                    $("#btnApprove").show();
                    $("#btnReject").show();
                    $("#APTreasuryTab").show();                    
                }else if(statusVal === "Completed"){

                    $("#cashApplicationAttachments").hide();
                    $("#cashApplicationAttachmentsGrid").show();


                    $("#APTreasuryAttachments").hide();
                    $("#APTreasuryAttachmentsGrid").show();

                    $("#serviceDeskAttachments").hide();
                    $("#serviceDeskAttachmentsGrid").show();

                    getAttachments(queryStrVal, "Cash Application", "cashApplicationAttachmentsGrid");
                    document.getElementById('cashApplicationInput').setAttribute('readonly', true);

                    getAttachments(queryStrVal, "AP Treasury", "APTreasuryAttachmentsGrid");
                    document.getElementById('APTreasuryInput').setAttribute('readonly', true);

                    getAttachments(queryStrVal, "Service Desk", "serviceDeskAttachmentsGrid");
                    document.getElementById('serviceDeskInput').setAttribute('readonly', true);


                    $("#cashApplicationTab").show();
                    $("#APTreasuryTab").show();
                    $("#serviceDeskTab").show();
                }               
            }				
		}); 		

		},  
		error: function(data){
			console.log(JSON.stringify(error));
		}
	}); 	
} 

function getAttachments(itemId,Title,attachmentDivIDs){
    
    // for(var i=0;i<attchmentFieldTitles.length;i++){
    //   $(attachmentDivID).empty();

    console.log("itemId: "+itemId);
    console.log("attachmentDivIDs: "+attachmentDivIDs);

      var attachmentDivID = "#";
      attachmentDivID += attachmentDivIDs;	 
     // attachmentDivID += "attachmentDivIDs"; 
   
      var restUrl = siteUrl + "/_api/web/lists/getbytitle('StopCashRequestAttachments')/items?&$select=*&$expand=File&$filter=(ItemID eq '"+ itemId +"' and Title eq '"+ Title +"')";
      bindDataTable(restUrl,attachmentDivID);	
    
    // } 
  }
  function bindDataTable(restUrl,attachmentDivID){
    // attachmentDivID = "#";
    // attachmentDivID+=attachmentDivID;   
    console.log("attachmentDivID: "+attachmentDivID);

    $.ajax({  
      url: restUrl, 
      method: "GET",
      async: false, 
      headers: {  
        "accept": "application/json;odata=verbose", 
      },  
      success: function(data) {          
         if (data.d.results.length > 0) {
          // alert("bind Data table success attachmentDivID: "+attachmentDivID);
          $(attachmentDivID).append(generateTableFromJson(data.d.results));   
         } else {  
           $(attachmentDivID).append("<span>No attachment found.</span>");    
         }  
       },   
       error: function(data) {
         $(attachmentDivID).append("<span>Error while Retrieving Attachments. Error : " + JSON.stringify(data) + "</span>");  
      }  
    });      
  }
  function generateTableFromJson(objArray) {  
    var onlyFileName;	
    var tableContent = '<table class="baxstyles" style="border: 1px">';  
    
      for (var i = 0; i < objArray.length; i++) {
      
        tableContent += '<tr style="border: 1px;">'; 
        
        tableContent += '<td class="nr" style="display:none;">' + objArray[i].ID + '</td>';  
       
        var itemID = objArray[i].ItemID;
        if(itemID == "undefined" || itemID == null || itemID == "") 
        {
          itemID = "";
        }
        tableContent += '<td style="display:none;">' + itemID + '</td>';
         
        var attachmentName = objArray[i].File.Name;
        onlyFileName = attachmentName.substr(0, attachmentName.lastIndexOf('.'));
        if(attachmentName == "undefined" || attachmentName == null || attachmentName == "")
        {
          attachmentName=""; 
        }
        tableContent += '<td style="display:none;">' + onlyFileName + '</td>';
    
        var attachmentLink = objArray[i].File.ServerRelativeUrl;
        var newHyperlink = attachmentLink;
        if(newHyperlink =="undefined" || newHyperlink ==null || newHyperlink =="")
        {
          attachmentLink=""; 
        }
        var fileLink = "https://worksites.baxter.com" + newHyperlink;
        tableContent += '<td>';
        tableContent += '<a  href="' + fileLink + '">'+ onlyFileName +'</a>';
        tableContent += '</td>';
               
        var itemTitle = objArray[i].File.Title;
        if(itemTitle == "undefined" || itemTitle == null || itemTitle == "")
        {
          itemTitle="";
        }
        tableContent += '<td style="display:none;">' + itemTitle + '</td>';
        
        // tableContent += '<td align="center">' + "<input type='button' id='btnDelete' class='baxstyles' value='Delete'>" + '</td>';
        
        tableContent += '</tr>';		
    }  
  
       return tableContent;  
  
}

function getQueryStrVal(){ 		
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++){
        hash = hashes[i].split('=');
        queryStrVal.push(hash[1]);
        queryStrVal[hash[0]] = hash[1];
    }
    if(queryStrVal[0] !== undefined &&  queryStrVal[0].length > 0){			
        retrieveStopCashRequestsDetails();        
    }else {
        $("#btnApprove").hide();
        $("#btnReject").hide();
        $("#btnUpdate").hide();
        $("#cashApplicationTab").hide();
        $("#APTreasuryTab").hide();
        $("#serviceDeskTab").hide();        
    }
}